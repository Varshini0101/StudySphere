import React, { useEffect, useState, useRef } from 'react';
import { Task } from '../types';
import { 
  Mic, 
  MicOff, 
  Save, 
  Trash2, 
  BookOpen, 
  FileText, 
  Clock, 
  AlertCircle,
  Play,
  Pause,
  Square,
  Volume2,
  Timer,
  AlertTriangle,
  RefreshCw
} from 'lucide-react';

interface VoiceControlProps {
  isListening: boolean;
  language: string;
  onTaskDetected: (task: Task) => void;
}

interface SavedNote {
  id: string;
  text: string;
  timestamp: number;
  audioUrl?: string;
  duration?: number;
}

const VoiceControl: React.FC<VoiceControlProps> = ({ isListening, language, onTaskDetected }) => {
  const [transcript, setTranscript] = useState('');
  const [fullTranscript, setFullTranscript] = useState('');
  const [savedNotes, setSavedNotes] = useState<SavedNote[]>([]);
  const [recordingMode, setRecordingMode] = useState<'notes' | 'assignment'>('notes');
  const [recordingBuffer, setRecordingBuffer] = useState<string[]>([]);
  const [bufferTimeout, setBufferTimeout] = useState<NodeJS.Timeout | null>(null);
  const [microphoneError, setMicrophoneError] = useState<string | null>(null);
  const [isTranscribing, setIsTranscribing] = useState(false);

  // Enhanced Audio Recording States
  const [isRecording, setIsRecording] = useState(false);
  const [audioURL, setAudioURL] = useState<string | null>(null);
  const mediaRecorder = useRef<MediaRecorder | null>(null);
  const audioChunks = useRef<Blob[]>([]);
  const [recordingTime, setRecordingTime] = useState(0);
  const timerInterval = useRef<NodeJS.Timeout | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const audioElement = useRef<HTMLAudioElement | null>(null);
  const [volume, setVolume] = useState(1);
  const [audioLevel, setAudioLevel] = useState(0);
  const audioContext = useRef<AudioContext | null>(null);
  const analyser = useRef<AnalyserNode | null>(null);
  const dataArray = useRef<Uint8Array | null>(null);
  const animationFrame = useRef<number | null>(null);
  const recognitionRef = useRef<SpeechRecognition | null>(null);

  // Language display names
  const languageNames: { [key: string]: string } = {
    'en-US': 'English',
    'ta-IN': 'தமிழ்',
    'ml-IN': 'മലയാളം',
    'te-IN': 'తెలుగు',
    'kn-IN': 'ಕನ್ನಡ',
    'hi-IN': 'हिंदी',
    'bn-IN': 'বাংলা',
    'mr-IN': 'मराठी',
    'gu-IN': 'ગુજરાતી',
    'pa-IN': 'ਪੰਜਾਬੀ'
  };

  // Check for browser support
  const checkBrowserSupport = () => {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      setMicrophoneError('Your browser does not support audio recording.');
      return false;
    }
    return true;
  };

  // Initialize audio context and analyzer
  const setupAudioAnalysis = (stream: MediaStream) => {
    try {
      const AudioContext = window.AudioContext || (window as any).webkitAudioContext;
      audioContext.current = new AudioContext();
      analyser.current = audioContext.current.createAnalyser();
      const source = audioContext.current.createMediaStreamSource(stream);
      source.connect(analyser.current);
      analyser.current.fftSize = 256;
      dataArray.current = new Uint8Array(analyser.current.frequencyBinCount);

      const updateAudioLevel = () => {
        if (!analyser.current || !dataArray.current) return;
        
        analyser.current.getByteFrequencyData(dataArray.current);
        const average = dataArray.current.reduce((a, b) => a + b) / dataArray.current.length;
        setAudioLevel(average / 128);

        animationFrame.current = requestAnimationFrame(updateAudioLevel);
      };

      updateAudioLevel();
    } catch (error) {
      console.error('Error setting up audio analysis:', error);
    }
  };

  // Start speech recognition
  const startSpeechRecognition = () => {
    try {
      if (!recognitionRef.current) {
        recognitionRef.current = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
      }

      const recognition = recognitionRef.current;
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = language;

      recognition.onstart = () => {
        setIsTranscribing(true);
      };

      recognition.onresult = (event) => {
        let interimTranscript = '';
        let finalTranscript = '';

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          const transcript = event.results[i][0].transcript;
          if (event.results[i].isFinal) {
            finalTranscript += transcript + ' ';
            setFullTranscript(prev => prev + ' ' + transcript);
          } else {
            interimTranscript += transcript;
          }
        }

        setTranscript(interimTranscript);
        
        if (finalTranscript) {
          setRecordingBuffer(prev => [...prev, finalTranscript]);
        }
      };

      recognition.onerror = (event) => {
        console.error('Speech recognition error:', event.error);
        setMicrophoneError(`Speech recognition error: ${event.error}`);
      };

      recognition.onend = () => {
        if (isRecording) {
          recognition.start();
        } else {
          setIsTranscribing(false);
        }
      };

      recognition.start();
    } catch (error) {
      console.error('Speech recognition error:', error);
      setMicrophoneError('Speech recognition is not supported in this browser.');
    }
  };

  // Enhanced start recording function
  const startRecording = async () => {
    setMicrophoneError(null);
    setFullTranscript('');
    setRecordingBuffer([]);
    
    if (!checkBrowserSupport()) {
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true
        }
      });

      const options = {
        mimeType: MediaRecorder.isTypeSupported('audio/webm') 
          ? 'audio/webm' 
          : 'audio/ogg'
      };

      mediaRecorder.current = new MediaRecorder(stream, options);
      
      audioChunks.current = [];
      setupAudioAnalysis(stream);

      mediaRecorder.current.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunks.current.push(event.data);
        }
      };

      mediaRecorder.current.onstop = () => {
        const audioBlob = new Blob(audioChunks.current, { 
          type: mediaRecorder.current?.mimeType || 'audio/webm' 
        });
        const url = URL.createObjectURL(audioBlob);
        setAudioURL(url);
      };

      mediaRecorder.current.start(1000);
      setIsRecording(true);
      setRecordingTime(0);

      timerInterval.current = setInterval(() => {
        setRecordingTime(prev => prev + 1);
      }, 1000);

      startSpeechRecognition();

    } catch (err) {
      console.error('Error accessing microphone:', err);
      setMicrophoneError(
        err instanceof DOMException && err.name === 'NotAllowedError'
          ? 'Please allow microphone access to record audio.'
          : 'Could not access the microphone. Please check your device settings.'
      );
    }
  };

  // Enhanced stop recording function
  const stopRecording = () => {
    if (mediaRecorder.current && mediaRecorder.current.state === 'recording') {
      mediaRecorder.current.stop();
      setIsRecording(false);

      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }

      if (timerInterval.current) {
        clearInterval(timerInterval.current);
      }

      if (animationFrame.current) {
        cancelAnimationFrame(animationFrame.current);
      }

      if (audioContext.current) {
        audioContext.current.close();
        audioContext.current = null;
      }

      mediaRecorder.current.stream.getTracks().forEach(track => track.stop());
    }
  };

  const formatTime = (seconds: number) => {
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    
    if (hrs > 0) {
      return `${hrs}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const togglePlayback = () => {
    if (!audioElement.current) return;

    if (isPlaying) {
      audioElement.current.pause();
    } else {
      audioElement.current.play();
    }
    setIsPlaying(!isPlaying);
  };

  // Handle audio playback events
  useEffect(() => {
    if (audioURL) {
      audioElement.current = new Audio(audioURL);
      audioElement.current.onended = () => setIsPlaying(false);
      audioElement.current.volume = volume;
    }
  }, [audioURL, volume]);

  // Cleanup
  useEffect(() => {
    return () => {
      if (timerInterval.current) {
        clearInterval(timerInterval.current);
      }
      if (animationFrame.current) {
        cancelAnimationFrame(animationFrame.current);
      }
      if (audioContext.current) {
        audioContext.current.close();
      }
      if (audioElement.current) {
        audioElement.current.pause();
        audioElement.current = null;
      }
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
    };
  }, []);

  const processTranscript = (text: string) => {
    if (recordingMode === 'notes') {
      const newNote: SavedNote = {
        id: Date.now().toString(),
        text,
        timestamp: Date.now(),
        audioUrl: audioURL || undefined,
        duration: recordingTime
      };
      setSavedNotes(prev => [...prev, newNote]);
      setAudioURL(null);
      setRecordingTime(0);
    } else {
      const task: Task = {
        id: Date.now().toString(),
        title: `Voice Recording - ${new Date().toLocaleDateString()}`,
        description: text,
        type: 'homework',
        priority: 'medium',
        dueDate: new Date().setDate(new Date().getDate() + 7),
        completed: false
      };
      onTaskDetected(task);
    }
  };

  const handleSave = () => {
    const completeText = [...recordingBuffer, transcript].filter(Boolean).join(' ');
    if (completeText.trim() || audioURL) {
      processTranscript(completeText);
      setRecordingBuffer([]);
      setTranscript('');
      setFullTranscript('');
    }
  };

  const handleClear = () => {
    setRecordingBuffer([]);
    setTranscript('');
    setFullTranscript('');
    if (audioURL) {
      URL.revokeObjectURL(audioURL);
      setAudioURL(null);
    }
    setRecordingTime(0);
  };

  const handleDeleteNote = (noteId: string) => {
    setSavedNotes(prev => {
      const noteToDelete = prev.find(note => note.id === noteId);
      if (noteToDelete?.audioUrl) {
        URL.revokeObjectURL(noteToDelete.audioUrl);
      }
      return prev.filter(note => note.id !== noteId);
    });
  };

  const getTranscriptDisplay = () => {
    const fullText = fullTranscript.trim();
    const interimText = transcript.trim();
    
    if (!fullText && !interimText) {
      return (
        <div className="flex items-center justify-center h-full text-gray-500">
          {isRecording ? (
            <div className="flex items-center gap-2">
              <div className="animate-pulse">●</div>
              <span>Recording in progress... Speak clearly into your microphone</span>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <AlertCircle className="h-5 w-5" />
              <span>Click the microphone to start recording</span>
            </div>
          )}
        </div>
      );
    }

    return (
      <div className="space-y-2">
        {fullText && (
          <p className="text-gray-800 whitespace-pre-wrap">{fullText}</p>
        )}
        {interimText && (
          <p className="text-gray-600 italic whitespace-pre-wrap">{interimText}</p>
        )}
      </div>
    );
  };

  return (
    <div className="space-y-4">
      {microphoneError && (
        <div className="bg-red-50 border-l-4 border-red-500 p-4 mb-4">
          <div className="flex items-center">
            <AlertTriangle className="h-5 w-5 text-red-500 mr-2" />
            <p className="text-red-700">{microphoneError}</p>
          </div>
        </div>
      )}

      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-semibold text-gray-900">Voice Recorder</h2>
        <div className="flex items-center gap-4">
          <div className="flex rounded-lg overflow-hidden">
            <button
              onClick={() => setRecordingMode('notes')}
              className={`px-4 py-2 flex items-center gap-2 ${
                recordingMode === 'notes'
                  ? 'bg-indigo-600 text-white'
                  : 'bg-gray-100 text-gray-600'
              }`}
            >
              <FileText className="h-4 w-4" />
              Notes
            </button>
            <button
              onClick={() => setRecordingMode('assignment')}
              className={`px-4 py-2 flex items-center gap-2 ${
                recordingMode === 'assignment'
                  ? 'bg-indigo-600 text-white'
                  : 'bg-gray-100 text-gray-600'
              }`}
            >
              <BookOpen className="h-4 w-4" />
              Assignment
            </button>
          </div>
          <span className="text-sm font-medium text-gray-600">
            {languageNames[language] || language}
          </span>
        </div>
      </div>

      <div className="bg-gradient-to-r from-indigo-50 to-pink-50 rounded-lg p-6 shadow-inner">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <button
              onClick={isRecording ? stopRecording : startRecording}
              className={`relative p-4 rounded-full ${
                isRecording 
                  ? 'bg-red-100 text-red-600 hover:bg-red-200' 
                  : 'bg-indigo-100 text-indigo-600 hover:bg-indigo-200'
              } transition-colors`}
            >
              {isRecording ? (
                <Square className="h-6 w-6" />
              ) : (
                <Mic className="h-6 w-6" />
              )}
              {isRecording && (
                <>
                  <span className="absolute top-0 right-0 h-3 w-3 bg-red-500 rounded-full animate-pulse" />
                  <div 
                    className="absolute inset-0 rounded-full border-2 border-red-500 scale-110"
                    style={{
                      transform: `scale(${1 + audioLevel * 0.5})`,
                      opacity: 0.5,
                      transition: 'transform 150ms ease'
                    }}
                  />
                </>
              )}
            </button>
            <div>
              <p className="text-lg font-medium text-gray-900">
                {isRecording ? 'Recording...' : 'Ready to record'}
              </p>
              {isRecording && (
                <div className="flex items-center gap-2">
                  <Timer className="h-4 w-4 text-red-600" />
                  <p className="text-sm text-red-600 font-medium">
                    {formatTime(recordingTime)}
                  </p>
                  {isTranscribing && (
                    <RefreshCw className="h-4 w-4 text-indigo-600 animate-spin" />
                  )}
                </div>
              )}
            </div>
          </div>

          {audioURL && !isRecording && (
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <Volume2 className="h-4 w-4 text-gray-600" />
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.1"
                  value={volume}
                  onChange={(e) => setVolume(parseFloat(e.target.value))}
                  className="w-20"
                />
              </div>
              <button
                onClick={togglePlayback}
                className="p-2 rounded-full bg-indigo-100 text-indigo-600 hover:bg-indigo-200 transition-colors"
              >
                {isPlaying ? (
                  <Pause className="h-4 w-4" />
                ) : (
                  <Play className="h-4 w-4" />
                )}
              </button>
            </div>
          )}
        </div>

        <div className="relative">
          <div className="bg-white/50 rounded-lg p-4 shadow-sm min-h-[200px] max-h-[400px] overflow-y-auto">
            {getTranscriptDisplay()}
          </div>
          
          <div className="absolute bottom-4 right-4 flex gap-2">
            {(transcript || recordingBuffer.length > 0 || audioURL) && (
              <>
                <button
                  onClick={handleClear}
                  className="p-2 rounded-full bg-red-100 text-red-600 hover:bg-red-200 transition-colors"
                  title="Clear recording"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
                <button
                  onClick={handleSave}
                  className="p-2 rounded-full bg-green-100 text-green-600 hover:bg-green-200 transition-colors"
                  title={recordingMode === 'notes' ? 'Save note' : 'Create assignment'}
                >
                  <Save className="h-4 w-4" />
                </button>
              </>
            )}
          </div>
        </div>
      </div>

      {recordingMode === 'notes' && savedNotes.length > 0 && (
        <div className="bg-white rounded-lg p-4 border border-gray-100">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Saved Notes</h3>
          <div className="space-y-3">
            {savedNotes.map(note => (
              <div key={note.id} className="bg-gray-50 rounded-lg p-4 relative group">
                <p className="text-gray-800 whitespace-pre-wrap">{note.text}</p>
                <div className="flex items-center justify-between mt-2">
                  <div className="text-sm text-gray-500">
                    <p>{new Date(note.timestamp).toLocaleString()}</p>
                    {note.duration && (
                      <p className="flex items-center gap-1 mt-1">
                        <Timer className="h-3 w-3" />
                        {formatTime(note.duration)}
                      </p>
                    )}
                  </div>
                  {note.audioUrl && (
                    <button
                      onClick={() => {
                        const audio = new Audio(note.audioUrl);
                        audio.play();
                      }}
                      className="p-2 rounded-full bg-indigo-100 text-indigo-600 hover:bg-indigo-200 transition-colors"
                    >
                      <Play className="h-4 w-4" />
                    </button>
                  )}
                </div>
                <button
                  onClick={() => handleDeleteNote(note.id)}
                  className="absolute top-2 right-2 p-1 rounded bg-red-100 text-red-600 opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default VoiceControl;