/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        'custom-magenta': {
          50: '#fdf2ff',
          100: '#fae5ff',
          200: '#f5ccff',
          300: '#f0a6ff',
          400: '#e571ff',
          500: '#d946ef',
          600: '#c026d3',
          700: '#a21caf',
          800: '#86198f',
          900: '#701a75',
          950: '#4a0d4f'
        },
        'dark-magenta': {
          50: '#fdf2ff',
          100: '#fae5ff',
          200: '#f5ccff',
          300: '#f0a6ff',
          400: '#e571ff',
          500: '#d946ef',
          600: '#c026d3',
          700: '#a21caf',
          800: '#86198f',
          900: '#701a75',
          950: '#4a0d4f'
        }
      },
      keyframes: {
        glow: {
          '0%, 100%': {
            filter: 'drop-shadow(0 0 8px rgba(217, 70, 239, 0.8)) drop-shadow(0 0 20px rgba(217, 70, 239, 0.6))',
            transform: 'scale(1)'
          },
          '50%': {
            filter: 'drop-shadow(0 0 12px rgba(217, 70, 239, 1)) drop-shadow(0 0 25px rgba(217, 70, 239, 0.8))',
            transform: 'scale(1.05)'
          },
        },
        float: {
          '0%, 100%': {
            transform: 'translateY(0)'
          },
          '50%': {
            transform: 'translateY(-10px)'
          }
        },
        pulse: {
          '0%, 100%': {
            opacity: 1
          },
          '50%': {
            opacity: 0.7
          }
        },
        shimmer: {
          '0%': {
            backgroundPosition: '-1000px 0',
          },
          '100%': {
            backgroundPosition: '1000px 0',
          },
        }
      },
      animation: {
        glow: 'glow 3s ease-in-out infinite',
        float: 'float 6s ease-in-out infinite',
        pulse: 'pulse 2s ease-in-out infinite',
        shimmer: 'shimmer 8s linear infinite'
      },
      backgroundImage: {
        'gradient-radial': 'radial-gradient(var(--tw-gradient-stops))',
      }
    },
  },
  plugins: [],
};