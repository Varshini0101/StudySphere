import React from 'react';
import { 
  BarChartIcon, 
  Calendar, 
  CheckCircle, 
  Clock,
  TrendingUp,
  Star,
  Info
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  CartesianGrid,
  Legend
} from 'recharts';
import { Task } from '../types';

interface InsightsDashboardProps {
  tasks: Task[];
}

const COLORS = ['#4F46E5', '#10B981', '#F59E0B', '#EF4444'];
const PRIORITY_COLORS = {
  high: '#EF4444',
  medium: '#F59E0B',
  low: '#10B981'
};

const GRADE_COLORS = {
  'A': '#10B981', // green
  'B': '#3B82F6', // blue
  'C': '#F59E0B', // yellow
  'D': '#F97316', // orange
  'F': '#EF4444'  // red
};

const calculateGrade = (score: number, daysLate: number): { grade: string; adjustedScore: number } => {
  // Initial grade based on score
  let grade = 'F';
  if (score >= 90) grade = 'A';
  else if (score >= 80) grade = 'B';
  else if (score >= 70) grade = 'C';
  else if (score >= 60) grade = 'D';

  // Penalty for late submission
  let adjustedScore = score;
  if (daysLate > 0) {
    // 5% penalty per day late, up to 30%
    const penalty = Math.min(daysLate * 5, 30);
    adjustedScore = Math.max(0, score - penalty);
    
    // Adjust grade based on new score
    if (adjustedScore >= 90) grade = 'A';
    else if (adjustedScore >= 80) grade = 'B';
    else if (adjustedScore >= 70) grade = 'C';
    else if (adjustedScore >= 60) grade = 'D';
    else grade = 'F';
  }

  return { grade, adjustedScore };
};

const InsightsDashboard: React.FC<InsightsDashboardProps> = ({ tasks }) => {
  const completedTasks = tasks.filter(task => task.completed).length;
  const pendingTasks = tasks.length - completedTasks;

  // Task type distribution data
  const typeDistribution = tasks.reduce((acc, task) => {
    acc[task.type] = (acc[task.type] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const pieData = Object.entries(typeDistribution).map(([name, value]) => ({
    name,
    value
  }));

  // Grade distribution data with deadline consideration
  const evaluatedTasks = tasks.filter(task => task.evaluation).map(task => {
    const dueDate = new Date(task.dueDate);
    const submissionDate = task.submission ? new Date(task.submission.submittedAt) : new Date();
    const daysLate = Math.max(0, Math.floor((submissionDate.getTime() - dueDate.getTime()) / (1000 * 60 * 60 * 24)));
    
    const { grade, adjustedScore } = calculateGrade(
      task.evaluation?.score || 0,
      daysLate
    );

    return {
      ...task,
      adjustedGrade: grade,
      adjustedScore,
      daysLate
    };
  });

  const gradeDistribution = evaluatedTasks.reduce((acc, task) => {
    acc[task.adjustedGrade] = (acc[task.adjustedGrade] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const gradeData = Object.entries(gradeDistribution).map(([grade, count]) => ({
    grade,
    count
  }));

  // Performance trend data
  const performanceData = evaluatedTasks
    .sort((a, b) => a.dueDate - b.dueDate)
    .map(task => ({
      name: task.title,
      originalScore: task.evaluation?.score || 0,
      adjustedScore: task.adjustedScore,
      daysLate: task.daysLate
    }));

  // Timeline data (next 7 days)
  const today = new Date();
  const next7Days = Array.from({ length: 7 }, (_, i) => {
    const date = new Date();
    date.setDate(today.getDate() + i);
    return date;
  });

  const timelineData = next7Days.map(date => {
    const dayTasks = tasks.filter(task => {
      const taskDate = new Date(task.dueDate);
      return taskDate.toDateString() === date.toDateString();
    });

    return {
      date: date.toLocaleDateString('en-US', { weekday: 'short' }),
      tasks: dayTasks.length,
      completed: dayTasks.filter(t => t.completed).length
    };
  });

  // Calculate average scores
  const averageOriginalScore = evaluatedTasks.length > 0
    ? Math.round(evaluatedTasks.reduce((sum, task) => sum + (task.evaluation?.score || 0), 0) / evaluatedTasks.length)
    : 0;

  const averageAdjustedScore = evaluatedTasks.length > 0
    ? Math.round(evaluatedTasks.reduce((sum, task) => sum + task.adjustedScore, 0) / evaluatedTasks.length)
    : 0;

  return (
    <div className="bg-white rounded-lg shadow-md p-6 space-y-8">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-semibold text-gray-900">Insights</h2>
        <TrendingUp className="h-6 w-6 text-indigo-600" />
      </div>

      {/* Grading System Explanation */}
      <div className="bg-indigo-50 rounded-lg p-4">
        <div className="flex items-center gap-2 mb-2">
          <Info className="h-5 w-5 text-indigo-600" />
          <h3 className="font-medium text-indigo-900">Grading System</h3>
        </div>
        <div className="space-y-2 text-sm text-indigo-800">
          <p><strong>Base Grades:</strong></p>
          <ul className="list-disc list-inside ml-4">
            <li>A: 90-100%</li>
            <li>B: 80-89%</li>
            <li>C: 70-79%</li>
            <li>D: 60-69%</li>
            <li>F: Below 60%</li>
          </ul>
          <p><strong>Late Submission Penalties:</strong></p>
          <ul className="list-disc list-inside ml-4">
            <li>5% deduction per day late</li>
            <li>Maximum penalty: 30%</li>
            <li>Final grade adjusted after penalties</li>
          </ul>
        </div>
      </div>

      {/* Overview Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-indigo-50 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <span className="text-indigo-900">Pending</span>
            <Clock className="h-5 w-5 text-indigo-600" />
          </div>
          <p className="text-2xl font-bold text-indigo-600 mt-2">{pendingTasks}</p>
        </div>
        <div className="bg-green-50 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <span className="text-green-900">Completed</span>
            <CheckCircle className="h-5 w-5 text-green-600" />
          </div>
          <p className="text-2xl font-bold text-green-600 mt-2">{completedTasks}</p>
        </div>
        <div className="bg-blue-50 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <span className="text-blue-900">Original Avg</span>
            <Star className="h-5 w-5 text-blue-600" />
          </div>
          <p className="text-2xl font-bold text-blue-600 mt-2">{averageOriginalScore}%</p>
        </div>
        <div className="bg-yellow-50 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <span className="text-yellow-900">Adjusted Avg</span>
            <Star className="h-5 w-5 text-yellow-600" />
          </div>
          <p className="text-2xl font-bold text-yellow-600 mt-2">{averageAdjustedScore}%</p>
        </div>
      </div>

      {/* Performance Comparison */}
      <div className="space-y-2">
        <h3 className="text-lg font-medium text-gray-900 flex items-center gap-2">
          <Star className="h-5 w-5 text-indigo-600" />
          Score Comparison (Original vs Adjusted)
        </h3>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={performanceData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" angle={-45} textAnchor="end" height={80} />
              <YAxis domain={[0, 100]} />
              <Tooltip />
              <Legend />
              <Bar dataKey="originalScore" name="Original Score" fill="#4F46E5" />
              <Bar dataKey="adjustedScore" name="Adjusted Score" fill="#F59E0B" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Grade Distribution */}
      <div className="space-y-2">
        <h3 className="text-lg font-medium text-gray-900 flex items-center gap-2">
          <BarChartIcon className="h-5 w-5 text-indigo-600" />
          Final Grade Distribution
        </h3>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={gradeData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="grade" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="count">
                {gradeData.map((entry, index) => (
                  <Cell 
                    key={`cell-${index}`}
                    fill={GRADE_COLORS[entry.grade as keyof typeof GRADE_COLORS]}
                  />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Timeline */}
      <div className="space-y-2">
        <h3 className="text-lg font-medium text-gray-900 flex items-center gap-2">
          <Calendar className="h-5 w-5 text-indigo-600" />
          7-Day Timeline
        </h3>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={timelineData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line 
                type="monotone" 
                dataKey="tasks" 
                stroke="#4F46E5" 
                name="Total Tasks"
              />
              <Line 
                type="monotone" 
                dataKey="completed" 
                stroke="#10B981" 
                name="Completed"
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Recent Evaluations */}
      <div className="space-y-2">
        <h3 className="text-lg font-medium text-gray-900">Recent Evaluations</h3>
        <div className="space-y-2">
          {evaluatedTasks
            .sort((a, b) => 
              new Date(b.evaluation?.evaluatedAt || 0).getTime() - 
              new Date(a.evaluation?.evaluatedAt || 0).getTime()
            )
            .slice(0, 3)
            .map((task, index) => (
              <div 
                key={index}
                className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
              >
                <div>
                  <p className="font-medium text-gray-900">{task.title}</p>
                  <div className="text-sm space-x-2">
                    <span className="text-gray-500">{task.type}</span>
                    {task.daysLate > 0 && (
                      <span className="text-red-500">
                        ({task.daysLate} day{task.daysLate > 1 ? 's' : ''} late)
                      </span>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="text-right">
                    <p className="text-sm text-gray-500">Original</p>
                    <span className={`font-bold ${
                      GRADE_COLORS[task.evaluation?.grade as keyof typeof GRADE_COLORS]
                        .replace('#', 'text-[#')
                        .concat(']')
                    }`}>
                      {task.evaluation?.grade} ({task.evaluation?.score}%)
                    </span>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-gray-500">Adjusted</p>
                    <span className={`font-bold ${
                      GRADE_COLORS[task.adjustedGrade as keyof typeof GRADE_COLORS]
                        .replace('#', 'text-[#')
                        .concat(']')
                    }`}>
                      {task.adjustedGrade} ({task.adjustedScore}%)
                    </span>
                  </div>
                </div>
              </div>
            ))}
        </div>
      </div>
    </div>
  );
};

export default InsightsDashboard;