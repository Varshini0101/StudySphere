import React, { useState } from 'react';
import { 
  Video, 
  Upload, 
  Globe, 
  Calendar,
  Clock,
  Users,
  Play,
  Plus,
  X,
  Link,
  ExternalLink
} from 'lucide-react';
import { VideoLecture, LiveSession, User } from '../types';

interface TeacherDashboardProps {
  currentUser: User;
}

interface VideoModalProps {
  onClose: () => void;
  onSubmit: (data: Omit<VideoLecture, 'id' | 'views' | 'uploadedAt'>) => void;
  teacher: User;
}

interface LiveSessionModalProps {
  onClose: () => void;
  onSubmit: (data: Omit<LiveSession, 'id' | 'status' | 'attendees'>) => void;
  teacher: User;
}

const VideoModal: React.FC<VideoModalProps> = ({ onClose, onSubmit, teacher }) => {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    videoUrl: '',
    thumbnailUrl: '',
    subject: teacher.subject || '',
    duration: 0
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({
      ...formData,
      teacherId: teacher.id,
      teacherName: teacher.name
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 max-w-2xl w-full mx-4">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-2xl font-semibold text-gray-900">Add Video Lecture</h3>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            <X className="h-6 w-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">Title</label>
            <input
              type="text"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">Description</label>
            <textarea
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
              rows={3}
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">Video URL</label>
            <input
              type="url"
              value={formData.videoUrl}
              onChange={(e) => setFormData({ ...formData, videoUrl: e.target.value })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">Thumbnail URL (optional)</label>
            <input
              type="url"
              value={formData.thumbnailUrl}
              onChange={(e) => setFormData({ ...formData, thumbnailUrl: e.target.value })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">Subject</label>
            <input
              type="text"
              value={formData.subject}
              onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">Duration (minutes)</label>
            <input
              type="number"
              value={formData.duration}
              onChange={(e) => setFormData({ ...formData, duration: parseInt(e.target.value) })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
              required
              min="1"
            />
          </div>

          <button
            type="submit"
            className="w-full bg-indigo-600 text-white py-2 px-4 rounded-md hover:bg-indigo-700 transition-colors"
          >
            Add Video Lecture
          </button>
        </form>
      </div>
    </div>
  );
};

const LiveSessionModal: React.FC<LiveSessionModalProps> = ({ onClose, onSubmit, teacher }) => {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    subject: teacher.subject || '',
    scheduledFor: '',
    duration: 60,
    meetingUrl: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({
      ...formData,
      teacherId: teacher.id,
      teacherName: teacher.name
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 max-w-2xl w-full mx-4">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-2xl font-semibold text-gray-900">Schedule Live Session</h3>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            <X className="h-6 w-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">Title</label>
            <input
              type="text"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">Description</label>
            <textarea
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
              rows={3}
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">Subject</label>
            <input
              type="text"
              value={formData.subject}
              onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">Schedule Date & Time</label>
            <input
              type="datetime-local"
              value={formData.scheduledFor}
              onChange={(e) => setFormData({ ...formData, scheduledFor: e.target.value })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">Duration (minutes)</label>
            <input
              type="number"
              value={formData.duration}
              onChange={(e) => setFormData({ ...formData, duration: parseInt(e.target.value) })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
              required
              min="15"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">Meeting URL</label>
            <input
              type="url"
              value={formData.meetingUrl}
              onChange={(e) => setFormData({ ...formData, meetingUrl: e.target.value })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
              required
            />
          </div>

          <button
            type="submit"
            className="w-full bg-indigo-600 text-white py-2 px-4 rounded-md hover:bg-indigo-700 transition-colors"
          >
            Schedule Session
          </button>
        </form>
      </div>
    </div>
  );
};

const TeacherDashboard: React.FC<TeacherDashboardProps> = ({ currentUser }) => {
  const [showVideoModal, setShowVideoModal] = useState(false);
  const [showLiveModal, setShowLiveModal] = useState(false);
  const [videos, setVideos] = useState<VideoLecture[]>([]);
  const [liveSessions, setLiveSessions] = useState<LiveSession[]>([]);

  const handleAddVideo = (videoData: Omit<VideoLecture, 'id' | 'views' | 'uploadedAt'>) => {
    const newVideo: VideoLecture = {
      ...videoData,
      id: `video-${Date.now()}`,
      views: 0,
      uploadedAt: new Date().toISOString()
    };
    setVideos(prev => [...prev, newVideo]);
  };

  const handleAddLiveSession = (sessionData: Omit<LiveSession, 'id' | 'status' | 'attendees'>) => {
    const newSession: LiveSession = {
      ...sessionData,
      id: `session-${Date.now()}`,
      status: 'scheduled',
      attendees: 0
    };
    setLiveSessions(prev => [...prev, newSession]);
  };

  const formatDuration = (minutes: number) => {
    const hrs = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return `${hrs > 0 ? `${hrs}h ` : ''}${mins}m`;
  };

  return (
    <div className="space-y-8">
      {/* Video Lectures Section */}
      <div className="bg-dark-magenta-900/30 backdrop-blur-sm rounded-lg shadow-lg border border-dark-magenta-700/50 p-6">
        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center gap-2">
            <Video className="h-6 w-6 text-custom-magenta-400 animate-glow" />
            <h2 className="text-2xl font-bold text-custom-magenta-200 neon-text font-['Poppins']">Video Lectures</h2>
          </div>
          <button
            onClick={() => setShowVideoModal(true)}
            className="flex items-center gap-2 bg-custom-magenta-600 text-white px-4 py-2 rounded-md hover:bg-custom-magenta-500 transition-all duration-300 neon-border"
          >
            <Plus className="h-5 w-5" />
            Add Video
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {videos.map(video => (
            <div key={video.id} className="bg-dark-magenta-900/50 rounded-lg overflow-hidden shadow-lg border border-dark-magenta-700/30 hover:border-custom-magenta-500/50 transition-all duration-300 group">
              <div className="aspect-video bg-dark-magenta-950 relative">
                {video.thumbnailUrl ? (
                  <img
                    src={video.thumbnailUrl}
                    alt={video.title}
                    className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity duration-300"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center">
                    <Video className="h-12 w-12 text-custom-magenta-400 group-hover:animate-glow" />
                  </div>
                )}
                <div className="absolute bottom-2 right-2 bg-dark-magenta-950/80 text-custom-magenta-200 px-2 py-1 rounded text-sm backdrop-blur-sm">
                  {formatDuration(video.duration)}
                </div>
              </div>
              <div className="p-4">
                <h3 className="font-semibold text-custom-magenta-200 mb-1 font-['Poppins']">{video.title}</h3>
                <p className="text-sm text-custom-magenta-300 mb-2">{video.description}</p>
                <div className="flex items-center justify-between text-sm text-custom-magenta-400">
                  <span>{video.subject}</span>
                  <span>{video.views} views</span>
                </div>
                <a
                  href={video.videoUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-3 flex items-center gap-2 text-custom-magenta-400 hover:text-custom-magenta-300 group-hover:neon-text"
                >
                  <Play className="h-4 w-4" />
                  Watch Video
                </a>
              </div>
            </div>
          ))}
        </div>

        {videos.length === 0 && (
          <div className="text-center py-12 text-custom-magenta-300">
            <Video className="h-12 w-12 mx-auto mb-4 text-custom-magenta-400 animate-glow" />
            <p className="font-['Poppins']">No video lectures yet</p>
            <p className="text-sm">Click the "Add Video" button to upload your first lecture</p>
          </div>
        )}
      </div>

      {/* Live Sessions Section */}
      <div className="bg-dark-magenta-900/30 backdrop-blur-sm rounded-lg shadow-lg border border-dark-magenta-700/50 p-6">
        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center gap-2">
            <Globe className="h-6 w-6 text-custom-magenta-400 animate-glow" />
            <h2 className="text-2xl font-bold text-custom-magenta-200 neon-text font-['Poppins']">Live Sessions</h2>
          </div>
          <button
            onClick={() => setShowLiveModal(true)}
            className="flex items-center gap-2 bg-custom-magenta-600 text-white px-4 py-2 rounded-md hover:bg-custom-magenta-500 transition-all duration-300 neon-border"
          >
            <Plus className="h-5 w-5" />
            Schedule Session
          </button>
        </div>

        <div className="space-y-4">
          {liveSessions.map(session => (
            <div
              key={session.id}
              className={`border rounded-lg p-4 backdrop-blur-sm transition-all duration-300 ${
                session.status === 'live'
                  ? 'bg-green-900/20 border-green-500/30 hover:border-green-400/50'
                  : session.status === 'ended'
                  ? 'bg-dark-magenta-900/20 border-dark-magenta-700/30'
                  : 'bg-dark-magenta-900/20 border-dark-magenta-700/30 hover:border-custom-magenta-500/50'
              }`}
            >
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="font-semibold text-custom-magenta-200 font-['Poppins']">{session.title}</h3>
                  <p className="text-sm text-custom-magenta-300 mt-1">{session.description}</p>
                </div>
                {session.status === 'live' && (
                  <span className="bg-green-900/30 text-green-400 px-2 py-1 rounded-full text-sm font-medium flex items-center gap-1 neon-text">
                    <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                    Live Now
                  </span>
                )}
              </div>

              <div className="mt-4 flex flex-wrap gap-4 text-sm">
                <div className="flex items-center gap-1 text-custom-magenta-300">
                  <Calendar className="h-4 w-4" />
                  <span>
                    {new Date(session.scheduledFor).toLocaleDateString('en-US', {
                      month: 'short',
                      day: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit'
                    })}
                  </span>
                </div>
                <div className="flex items-center gap-1 text-custom-magenta-300">
                  <Clock className="h-4 w-4" />
                  <span>{formatDuration(session.duration)}</span>
                </div>
                <div className="flex items-center gap-1 text-custom-magenta-300">
                  <Users className="h-4 w-4" />
                  <span>{session.attendees} attendees</span>
                </div>
              </div>

              <div className="mt-4 flex items-center justify-between">
                <span className="text-sm text-custom-magenta-400">{session.subject}</span>
                <a
                  href={session.meetingUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`flex items-center gap-2 px-4 py-2 rounded-md transition-all duration-300 ${
                    session.status === 'live'
                      ? 'bg-green-600 text-white hover:bg-green-500 neon-border'
                      : session.status === 'ended'
                      ? 'bg-dark-magenta-800/50 text-custom-magenta-300 cursor-not-allowed'
                      : 'bg-custom-magenta-600 text-white hover:bg-custom-magenta-500 neon-border'
                  }`}
                >
                  {session.status === 'live' ? (
                    <>
                      <Link className="h-4 w-4" />
                      Join Now
                    </>
                  ) : session.status === 'ended' ? (
                    'Session Ended'
                  ) : (
                    <>
                      <ExternalLink className="h-4 w-4" />
                      Open Meeting Link
                    </>
                  )}
                </a>
              </div>
            </div>
          ))}
        </div>

        {liveSessions.length === 0 && (
          <div className="text-center py-12 text-custom-magenta-300">
            <Globe className="h-12 w-12 mx-auto mb-4 text-custom-magenta-400 animate-glow" />
            <p className="font-['Poppins']">No live sessions scheduled</p>
            <p className="text-sm">Click the "Schedule Session" button to create your first live session</p>
          </div>
        )}
      </div>

      {showVideoModal && (
        <VideoModal
          onClose={() => setShowVideoModal(false)}
          onSubmit={handleAddVideo}
          teacher={currentUser}
        />
      )}

      {showLiveModal && (
        <LiveSessionModal
          onClose={() => setShowLiveModal(false)}
          onSubmit={handleAddLiveSession}
          teacher={currentUser}
        />
      )}
    </div>
  );
};

export default TeacherDashboard;