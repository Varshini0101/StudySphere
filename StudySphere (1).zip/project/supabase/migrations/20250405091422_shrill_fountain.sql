/*
  # Initial Schema Setup for Task Management System

  1. New Tables
    - `users`
      - `id` (uuid, primary key)
      - `name` (text)
      - `email` (text, unique)
      - `role` (text)
      - `subject` (text, optional)
      - `class` (text, optional)
      - `created_at` (timestamp)

    - `tasks`
      - `id` (uuid, primary key)
      - `title` (text)
      - `description` (text)
      - `type` (text)
      - `priority` (text)
      - `due_date` (timestamp)
      - `completed` (boolean)
      - `subject` (text, optional)
      - `assigned_by` (uuid, references users)
      - `created_at` (timestamp)

    - `task_assignments`
      - `id` (uuid, primary key)
      - `task_id` (uuid, references tasks)
      - `student_id` (uuid, references users)
      - `created_at` (timestamp)

    - `submissions`
      - `id` (uuid, primary key)
      - `task_id` (uuid, references tasks)
      - `student_id` (uuid, references users)
      - `file_url` (text)
      - `notes` (text)
      - `submitted_at` (timestamp)

    - `evaluations`
      - `id` (uuid, primary key)
      - `submission_id` (uuid, references submissions)
      - `grade` (text)
      - `comments` (text)
      - `evaluated_by` (uuid, references users)
      - `evaluated_at` (timestamp)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Create users table
CREATE TABLE users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text UNIQUE NOT NULL,
  role text NOT NULL CHECK (role IN ('teacher', 'student')),
  subject text,
  class text,
  created_at timestamptz DEFAULT now()
);

-- Create tasks table
CREATE TABLE tasks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  type text NOT NULL,
  priority text NOT NULL CHECK (priority IN ('low', 'medium', 'high')),
  due_date timestamptz NOT NULL,
  completed boolean DEFAULT false,
  subject text,
  assigned_by uuid REFERENCES users(id),
  created_at timestamptz DEFAULT now()
);

-- Create task assignments table
CREATE TABLE task_assignments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  task_id uuid REFERENCES tasks(id) ON DELETE CASCADE,
  student_id uuid REFERENCES users(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  UNIQUE(task_id, student_id)
);

-- Create submissions table
CREATE TABLE submissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  task_id uuid REFERENCES tasks(id) ON DELETE CASCADE,
  student_id uuid REFERENCES users(id) ON DELETE CASCADE,
  file_url text NOT NULL,
  notes text,
  submitted_at timestamptz DEFAULT now(),
  UNIQUE(task_id, student_id)
);

-- Create evaluations table
CREATE TABLE evaluations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  submission_id uuid REFERENCES submissions(id) ON DELETE CASCADE,
  grade text NOT NULL CHECK (grade IN ('A', 'B', 'C', 'D', 'F')),
  comments text,
  evaluated_by uuid REFERENCES users(id),
  evaluated_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE task_assignments ENABLE ROW LEVEL SECURITY;
ALTER TABLE submissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE evaluations ENABLE ROW LEVEL SECURITY;

-- Create policies for users
CREATE POLICY "Users can view their own data"
  ON users
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

-- Create policies for tasks
CREATE POLICY "Teachers can create tasks"
  ON tasks
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM users
      WHERE id = auth.uid()
      AND role = 'teacher'
    )
  );

CREATE POLICY "Teachers can view their created tasks"
  ON tasks
  FOR SELECT
  TO authenticated
  USING (
    assigned_by = auth.uid() OR
    EXISTS (
      SELECT 1 FROM task_assignments
      WHERE task_assignments.task_id = tasks.id
      AND task_assignments.student_id = auth.uid()
    )
  );

-- Create policies for task assignments
CREATE POLICY "Teachers can assign tasks"
  ON task_assignments
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM users
      WHERE id = auth.uid()
      AND role = 'teacher'
    )
  );

CREATE POLICY "Users can view their task assignments"
  ON task_assignments
  FOR SELECT
  TO authenticated
  USING (
    student_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM tasks
      WHERE tasks.id = task_assignments.task_id
      AND tasks.assigned_by = auth.uid()
    )
  );

-- Create policies for submissions
CREATE POLICY "Students can submit assignments"
  ON submissions
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM task_assignments
      WHERE task_assignments.task_id = task_id
      AND task_assignments.student_id = auth.uid()
    )
  );

CREATE POLICY "Users can view relevant submissions"
  ON submissions
  FOR SELECT
  TO authenticated
  USING (
    student_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM tasks
      WHERE tasks.id = submissions.task_id
      AND tasks.assigned_by = auth.uid()
    )
  );

-- Create policies for evaluations
CREATE POLICY "Teachers can create evaluations"
  ON evaluations
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM users
      WHERE id = auth.uid()
      AND role = 'teacher'
    )
  );

CREATE POLICY "Users can view relevant evaluations"
  ON evaluations
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM submissions
      WHERE submissions.id = evaluations.submission_id
      AND (
        submissions.student_id = auth.uid() OR
        EXISTS (
          SELECT 1 FROM tasks
          WHERE tasks.id = submissions.task_id
          AND tasks.assigned_by = auth.uid()
        )
      )
    )
  );