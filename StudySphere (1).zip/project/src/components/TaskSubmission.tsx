import React, { useState } from 'react';
import { Upload, FileText } from 'lucide-react';
import { Task, User } from '../types';

interface TaskSubmissionProps {
  task: Task;
  currentUser: User;
  onSubmit: (taskId: string, submission: { fileUrl: string; notes: string }) => void;
}

const TaskSubmission: React.FC<TaskSubmissionProps> = ({ task, currentUser, onSubmit }) => {
  const [notes, setNotes] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!file) return;

    setUploading(true);
    try {
      // Create a unique file name
      const fileName = `${task.id}-${currentUser.id}-${file.name}`;
      
      // In a real app, upload the file to storage and get the URL
      const fileUrl = URL.createObjectURL(file);
      
      onSubmit(task.id, {
        fileUrl,
        notes
      });

      setNotes('');
      setFile(null);
    } catch (error) {
      console.error('Error uploading file:', error);
    } finally {
      setUploading(false);
    }
  };

  if (task.submission) {
    return (
      <div className="bg-gray-50 rounded-lg p-4 mt-4">
        <div className="flex items-center gap-2 text-gray-600 mb-2">
          <FileText className="h-5 w-5" />
          <span>Submitted</span>
        </div>
        <a
          href={task.submission.fileUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="text-indigo-600 hover:text-indigo-800 underline"
        >
          View Submission
        </a>
        {task.evaluation && (
          <div className="mt-4 border-t pt-4">
            <h4 className="font-medium text-gray-900">Evaluation</h4>
            <p className="text-gray-600">Grade: {task.evaluation.grade}</p>
            <p className="text-gray-600">Comments: {task.evaluation.comments}</p>
          </div>
        )}
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="bg-gray-50 rounded-lg p-4 mt-4">
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700">
            Upload Assignment
          </label>
          <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md">
            <div className="space-y-1 text-center">
              <Upload className="mx-auto h-12 w-12 text-gray-400" />
              <div className="flex text-sm text-gray-600">
                <label
                  htmlFor="file-upload"
                  className="relative cursor-pointer bg-white rounded-md font-medium text-indigo-600 hover:text-indigo-500 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-indigo-500"
                >
                  <span>Upload a file</span>
                  <input
                    id="file-upload"
                    name="file-upload"
                    type="file"
                    className="sr-only"
                    onChange={(e) => setFile(e.target.files?.[0] || null)}
                  />
                </label>
                <p className="pl-1">or drag and drop</p>
              </div>
              <p className="text-xs text-gray-500">
                PDF, DOC, DOCX up to 10MB
              </p>
            </div>
          </div>
          {file && (
            <p className="mt-2 text-sm text-gray-600">
              Selected file: {file.name}
            </p>
          )}
        </div>

        <div>
          <label htmlFor="notes" className="block text-sm font-medium text-gray-700">
            Additional Notes
          </label>
          <textarea
            id="notes"
            rows={3}
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
            placeholder="Add any notes about your submission..."
          />
        </div>

        <button
          type="submit"
          disabled={!file || uploading}
          className="w-full bg-indigo-600 text-white py-2 px-4 rounded-md hover:bg-indigo-700 transition-colors disabled:bg-gray-400"
        >
          {uploading ? 'Uploading...' : 'Submit Assignment'}
        </button>
      </div>
    </form>
  );
};

export default TaskSubmission;