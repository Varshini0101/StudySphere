import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot } from 'lucide-react';
import { Task, ChatMessage } from '../types';

interface ChatInterfaceProps {
  tasks: Task[];
  onTaskUpdate: (taskId: number, updates: Partial<Task>) => void;
}

const ChatInterface: React.FC<ChatInterfaceProps> = ({ tasks, onTaskUpdate }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      text: "Hi! I'm your study buddy. Ask me about your tasks, deadlines, or if you need study tips!",
      sender: 'bot',
      timestamp: Date.now(),
    },
  ]);
  const [input, setInput] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const formatTaskDetails = (task: Task): string => {
    const dueDate = new Date(task.dueDate).toLocaleDateString('en-US', {
      weekday: 'long',
      month: 'long',
      day: 'numeric',
    });
    const status = task.completed ? '✅ Completed' : '⏳ Pending';
    return `📝 ${task.title}
    Type: ${task.type}
    Priority: ${task.priority}
    Due: ${dueDate}
    Status: ${status}
    ${task.description ? `Details: ${task.description}` : ''}`;
  };

  const processQuery = (query: string): string => {
    const lowerQuery = query.toLowerCase();
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    // Handle "today's tasks" query
    if (lowerQuery.includes('today') || lowerQuery.includes('schedule for today')) {
      const todayTasks = tasks.filter(task => {
        const taskDate = new Date(task.dueDate);
        taskDate.setHours(0, 0, 0, 0);
        return taskDate.getTime() === today.getTime();
      });

      if (todayTasks.length === 0) return "You don't have any tasks due today! 🎉";
      return `Here are your tasks for today:\n\n${todayTasks.map(formatTaskDetails).join('\n\n')}`;
    }

    // Handle "all tasks" query
    if (lowerQuery.includes('all tasks') || lowerQuery.includes('what are the task')) {
      if (tasks.length === 0) return "You don't have any tasks yet!";
      const pendingTasks = tasks.filter(task => !task.completed);
      return `Here are all your pending tasks:\n\n${pendingTasks.map(formatTaskDetails).join('\n\n')}`;
    }

    // Handle "tomorrow's tasks" query
    if (lowerQuery.includes('tomorrow')) {
      const tomorrowTasks = tasks.filter(task => {
        const taskDate = new Date(task.dueDate);
        taskDate.setHours(0, 0, 0, 0);
        return taskDate.getTime() === tomorrow.getTime();
      });
      
      if (tomorrowTasks.length === 0) return "You don't have any tasks due tomorrow!";
      return `Here are your tasks due tomorrow:\n\n${tomorrowTasks.map(formatTaskDetails).join('\n\n')}`;
    }

    // Handle subject-specific queries
    const subjects = ['math', 'science', 'english', 'history'];
    for (const subject of subjects) {
      if (lowerQuery.includes(subject)) {
        const subjectTasks = tasks.filter(task => 
          task.subject?.toLowerCase() === subject && !task.completed
        );
        if (subjectTasks.length === 0) return `No pending tasks for ${subject}!`;
        return `Here are your ${subject} tasks:\n\n${subjectTasks.map(formatTaskDetails).join('\n\n')}`;
      }
    }

    // Handle priority queries
    if (lowerQuery.includes('urgent') || lowerQuery.includes('high priority')) {
      const urgentTasks = tasks.filter(task => 
        task.priority === 'high' && !task.completed
      );
      if (urgentTasks.length === 0) return "You don't have any high-priority tasks!";
      return `Here are your urgent tasks:\n\n${urgentTasks.map(formatTaskDetails).join('\n\n')}`;
    }

    // Handle task type queries
    const taskTypes = ['homework', 'quiz', 'test', 'project'];
    for (const type of taskTypes) {
      if (lowerQuery.includes(type)) {
        const typeTasks = tasks.filter(task => 
          task.type.toLowerCase() === type && !task.completed
        );
        if (typeTasks.length === 0) return `No pending ${type}s!`;
        return `Here are your ${type}s:\n\n${typeTasks.map(formatTaskDetails).join('\n\n')}`;
      }
    }

    // Handle completion status queries
    if (lowerQuery.includes('completed')) {
      const completedTasks = tasks.filter(task => task.completed);
      if (completedTasks.length === 0) return "You haven't completed any tasks yet. Keep going!";
      return `Here are your completed tasks:\n\n${completedTasks.map(formatTaskDetails).join('\n\n')}`;
    }

    // Handle "mark as complete" requests
    if (lowerQuery.includes('mark') && lowerQuery.includes('complete')) {
      const taskTitle = query.toLowerCase().replace('mark', '').replace('complete', '').replace('as', '').trim();
      const task = tasks.findIndex(t => t.title.toLowerCase().includes(taskTitle));
      if (task !== -1) {
        onTaskUpdate(task, { completed: true });
        return `Great job! I've marked "${tasks[task].title}" as complete. 🎉`;
      }
    }

    // Handle upcoming deadlines query
    if (lowerQuery.includes('upcoming') || lowerQuery.includes('next')) {
      const upcomingTasks = tasks
        .filter(task => !task.completed && new Date(task.dueDate) > today)
        .sort((a, b) => a.dueDate - b.dueDate)
        .slice(0, 3);

      if (upcomingTasks.length === 0) return "You don't have any upcoming tasks!";
      return `Here are your upcoming deadlines:\n\n${upcomingTasks.map(formatTaskDetails).join('\n\n')}`;
    }

    // Study tips
    if (lowerQuery.includes('study tip') || lowerQuery.includes('help me study')) {
      const tips = [
        "Try the Pomodoro Technique: Study for 25 minutes, then take a 5-minute break!",
        "Teaching someone else is one of the best ways to learn. Try explaining the concept to a friend!",
        "Create mind maps to connect different concepts and see the bigger picture.",
        "Take regular breaks and stay hydrated - it helps with focus and memory!",
        "Review your notes within 24 hours of taking them - it significantly improves retention!",
        "Use active recall - close your books and try to explain the topic in your own words.",
        "Break large tasks into smaller, manageable chunks.",
        "Study in a quiet environment with good lighting and minimal distractions.",
        "Get enough sleep - it's crucial for memory consolidation!",
        "Use color-coding in your notes to help organize information."
      ];
      return tips[Math.floor(Math.random() * tips.length)];
    }

    return "I can help you with:\n- Today's tasks\n- Tomorrow's tasks\n- Subject-specific tasks\n- High-priority tasks\n- Upcoming deadlines\n- Completed tasks\n- Study tips\n\nJust ask me what you'd like to know! 📚";
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      text: input,
      sender: 'user',
      timestamp: Date.now(),
    };

    const botResponse: ChatMessage = {
      id: (Date.now() + 1).toString(),
      text: processQuery(input),
      sender: 'bot',
      timestamp: Date.now() + 1,
    };

    setMessages(prev => [...prev, userMessage, botResponse]);
    setInput('');
  };

  return (
    <div className="bg-white rounded-lg shadow-md h-[500px] flex flex-col">
      <div className="p-4 border-b flex items-center gap-2">
        <Bot className="h-6 w-6 text-indigo-600" />
        <h2 className="text-lg font-semibold text-gray-900">Study Buddy</h2>
      </div>
      
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-[80%] rounded-lg p-3 ${
                message.sender === 'user'
                  ? 'bg-indigo-600 text-white'
                  : 'bg-gray-100 text-gray-900'
              }`}
            >
              <p className="whitespace-pre-line">{message.text}</p>
              <p className="text-xs mt-1 opacity-75">
                {new Date(message.timestamp).toLocaleTimeString()}
              </p>
            </div>
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>

      <form onSubmit={handleSubmit} className="p-4 border-t">
        <div className="flex gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask about your tasks or request study tips..."
            className="flex-1 rounded-lg border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
          />
          <button
            type="submit"
            className="bg-indigo-600 text-white p-2 rounded-lg hover:bg-indigo-700 transition-colors"
          >
            <Send className="h-5 w-5" />
          </button>
        </div>
      </form>
    </div>
  );
};

export default ChatInterface;