import React, { useState, useEffect, useRef } from 'react';
import { Timer, Play, Pause, RotateCcw, Bell, Coffee, Brain, Settings, X, Check, Volume2, Moon, Sun } from 'lucide-react';

type TimerMethod = 'pomodoro' | '52-17' | 'custom';
type TimerState = 'work' | 'break';
type Theme = 'light' | 'dark';

interface TimerSettings {
  workDuration: number;
  breakDuration: number;
  longBreakDuration: number;
  sessionsBeforeLongBreak: number;
}

const DEFAULT_SETTINGS: Record<TimerMethod, TimerSettings> = {
  pomodoro: {
    workDuration: 25 * 60,
    breakDuration: 5 * 60,
    longBreakDuration: 15 * 60,
    sessionsBeforeLongBreak: 4
  },
  '52-17': {
    workDuration: 52 * 60,
    breakDuration: 17 * 60,
    longBreakDuration: 30 * 60,
    sessionsBeforeLongBreak: 2
  },
  custom: {
    workDuration: 45 * 60,
    breakDuration: 10 * 60,
    longBreakDuration: 20 * 60,
    sessionsBeforeLongBreak: 3
  }
};

const FocusMode: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [method, setMethod] = useState<TimerMethod>('pomodoro');
  const [settings, setSettings] = useState<TimerSettings>(DEFAULT_SETTINGS[method]);
  const [timeLeft, setTimeLeft] = useState(settings.workDuration);
  const [isRunning, setIsRunning] = useState(false);
  const [timerState, setTimerState] = useState<TimerState>('work');
  const [sessions, setSessions] = useState(0);
  const [showSettings, setShowSettings] = useState(false);
  const [customSettings, setCustomSettings] = useState<TimerSettings>(DEFAULT_SETTINGS.custom);
  const [volume, setVolume] = useState(0.5);
  const [theme, setTheme] = useState<Theme>('light');
  const [showMotivationalQuote, setShowMotivationalQuote] = useState(true);
  
  const intervalRef = useRef<number>();
  const audioRef = useRef<HTMLAudioElement>(null);

  // Motivational quotes for study sessions
  const motivationalQuotes = [
    "Focus on the process, not the outcome.",
    "Small progress is still progress.",
    "Stay focused, stay determined.",
    "Every minute of focus counts.",
    "Your future self will thank you.",
    "Learning is a journey, not a destination.",
    "Concentration is the secret of strength.",
    "One task at a time leads to success.",
    "Stay present, stay focused.",
    "Quality focus beats quantity every time."
  ];

  const [currentQuote, setCurrentQuote] = useState(
    motivationalQuotes[Math.floor(Math.random() * motivationalQuotes.length)]
  );

  useEffect(() => {
    // Rotate quotes every 5 minutes if showing quotes is enabled
    if (showMotivationalQuote && isRunning) {
      const quoteInterval = setInterval(() => {
        setCurrentQuote(motivationalQuotes[Math.floor(Math.random() * motivationalQuotes.length)]);
      }, 5 * 60 * 1000);
      
      return () => clearInterval(quoteInterval);
    }
  }, [showMotivationalQuote, isRunning]);

  useEffect(() => {
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, []);

  useEffect(() => {
    if (method !== 'custom') {
      setSettings(DEFAULT_SETTINGS[method]);
      setTimeLeft(DEFAULT_SETTINGS[method].workDuration);
    } else {
      setSettings(customSettings);
      setTimeLeft(customSettings.workDuration);
    }
    setTimerState('work');
    setSessions(0);
    setIsRunning(false);
  }, [method, customSettings]);

  const playSound = () => {
    if (audioRef.current) {
      audioRef.current.volume = volume;
      audioRef.current.play().catch(console.error);
    }
  };

  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const toggleTimer = () => {
    if (isRunning) {
      clearInterval(intervalRef.current);
    } else {
      intervalRef.current = window.setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            playSound();
            const currentSettings = method === 'custom' ? customSettings : DEFAULT_SETTINGS[method];
            
            if (timerState === 'work') {
              const newSessions = sessions + 1;
              setSessions(newSessions);
              
              if (newSessions % currentSettings.sessionsBeforeLongBreak === 0) {
                setTimerState('break');
                return currentSettings.longBreakDuration;
              } else {
                setTimerState('break');
                return currentSettings.breakDuration;
              }
            } else {
              setTimerState('work');
              return currentSettings.workDuration;
            }
          }
          return prev - 1;
        });
      }, 1000);
    }
    setIsRunning(!isRunning);
  };

  const resetTimer = () => {
    clearInterval(intervalRef.current);
    setIsRunning(false);
    setTimerState('work');
    setSessions(0);
    setTimeLeft(settings.workDuration);
  };

  const getProgressColor = () => {
    if (timerState === 'work') {
      return theme === 'light' ? 'from-indigo-500 to-blue-500' : 'from-indigo-400 to-blue-400';
    }
    return theme === 'light' ? 'from-green-500 to-emerald-500' : 'from-green-400 to-emerald-400';
  };

  const progress = (timeLeft / (timerState === 'work' ? settings.workDuration : settings.breakDuration)) * 100;

  return (
    <>
      <button
        onClick={() => setIsOpen(true)}
        className={`fixed bottom-6 right-6 ${
          theme === 'light' ? 'bg-indigo-600' : 'bg-indigo-400'
        } text-white p-4 rounded-full shadow-lg hover:bg-indigo-700 transition-colors`}
      >
        <Brain className="h-6 w-6" />
      </button>

      {isOpen && (
        <div className={`fixed inset-0 ${
          theme === 'light' ? 'bg-black/50' : 'bg-black/70'
        } flex items-center justify-center z-50`}>
          <div className={`${
            theme === 'light' 
              ? 'bg-white' 
              : 'bg-gray-900'
          } rounded-xl p-6 max-w-md w-full mx-4 relative`}>
            <div className="absolute top-4 right-4 flex items-center gap-4">
              <button
                onClick={() => setTheme(theme === 'light' ? 'dark' : 'light')}
                className={`text-gray-500 hover:text-gray-700 ${
                  theme === 'dark' ? 'text-gray-400 hover:text-gray-300' : ''
                }`}
              >
                {theme === 'light' ? <Moon className="h-5 w-5" /> : <Sun className="h-5 w-5" />}
              </button>
              <button
                onClick={() => setIsOpen(false)}
                className={`text-gray-500 hover:text-gray-700 ${
                  theme === 'dark' ? 'text-gray-400 hover:text-gray-300' : ''
                }`}
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="text-center mb-6">
              <h2 className={`text-2xl font-bold ${
                theme === 'light' ? 'text-gray-900' : 'text-white'
              }`}>Focus Mode</h2>
              <p className={`${
                theme === 'light' ? 'text-gray-600' : 'text-gray-400'
              }`}>Stay focused and productive</p>
            </div>

            <div className="flex justify-center space-x-4 mb-6">
              <button
                onClick={() => setMethod('pomodoro')}
                className={`px-4 py-2 rounded-lg ${
                  method === 'pomodoro'
                    ? theme === 'light'
                      ? 'bg-indigo-100 text-indigo-700'
                      : 'bg-indigo-900 text-indigo-200'
                    : theme === 'light'
                    ? 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                    : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
                }`}
              >
                Pomodoro
              </button>
              <button
                onClick={() => setMethod('52-17')}
                className={`px-4 py-2 rounded-lg ${
                  method === '52-17'
                    ? theme === 'light'
                      ? 'bg-indigo-100 text-indigo-700'
                      : 'bg-indigo-900 text-indigo-200'
                    : theme === 'light'
                    ? 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                    : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
                }`}
              >
                52/17 Rule
              </button>
              <button
                onClick={() => setMethod('custom')}
                className={`px-4 py-2 rounded-lg ${
                  method === 'custom'
                    ? theme === 'light'
                      ? 'bg-indigo-100 text-indigo-700'
                      : 'bg-indigo-900 text-indigo-200'
                    : theme === 'light'
                    ? 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                    : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
                }`}
              >
                Custom
              </button>
            </div>

            <div className="relative">
              <div
                className="w-full h-2 bg-gray-200 rounded-full overflow-hidden mb-8"
                style={{
                  background: `linear-gradient(to right, 
                    ${timerState === 'work' ? '#6366f1' : '#10b981'} ${progress}%, 
                    ${theme === 'light' ? '#e5e7eb' : '#374151'} ${progress}%)`
                }}
              />

              <div className="text-center mb-8">
                <div className={`text-6xl font-bold mb-2 font-mono ${
                  theme === 'light' ? 'text-gray-900' : 'text-white'
                }`}>
                  {formatTime(timeLeft)}
                </div>
                <div className={`capitalize ${
                  theme === 'light' ? 'text-gray-600' : 'text-gray-400'
                }`}>
                  {timerState} Time {sessions > 0 && `(Session ${sessions})`}
                </div>
              </div>

              {showMotivationalQuote && (
                <div className={`text-center mb-6 italic ${
                  theme === 'light' ? 'text-gray-600' : 'text-gray-400'
                }`}>
                  "{currentQuote}"
                </div>
              )}

              <div className="flex justify-center space-x-4">
                <button
                  onClick={toggleTimer}
                  className={`p-4 rounded-full ${
                    isRunning
                      ? theme === 'light'
                        ? 'bg-red-100 text-red-600 hover:bg-red-200'
                        : 'bg-red-900 text-red-300 hover:bg-red-800'
                      : theme === 'light'
                      ? 'bg-green-100 text-green-600 hover:bg-green-200'
                      : 'bg-green-900 text-green-300 hover:bg-green-800'
                  }`}
                >
                  {isRunning ? <Pause className="h-6 w-6" /> : <Play className="h-6 w-6" />}
                </button>
                <button
                  onClick={resetTimer}
                  className={`p-4 rounded-full ${
                    theme === 'light'
                      ? 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                      : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
                  }`}
                >
                  <RotateCcw className="h-6 w-6" />
                </button>
                {method === 'custom' && (
                  <button
                    onClick={() => setShowSettings(true)}
                    className={`p-4 rounded-full ${
                      theme === 'light'
                        ? 'bg-indigo-100 text-indigo-600 hover:bg-indigo-200'
                        : 'bg-indigo-900 text-indigo-300 hover:bg-indigo-800'
                    }`}
                  >
                    <Settings className="h-6 w-6" />
                  </button>
                )}
              </div>

              <div className="mt-6 flex items-center justify-center gap-4">
                <div className="flex items-center gap-2">
                  <Volume2 className={`h-4 w-4 ${
                    theme === 'light' ? 'text-gray-600' : 'text-gray-400'
                  }`} />
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.1"
                    value={volume}
                    onChange={(e) => setVolume(parseFloat(e.target.value))}
                    className="w-20"
                  />
                </div>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={showMotivationalQuote}
                    onChange={(e) => setShowMotivationalQuote(e.target.checked)}
                    className="rounded border-gray-300"
                  />
                  <span className={`text-sm ${
                    theme === 'light' ? 'text-gray-600' : 'text-gray-400'
                  }`}>
                    Show Quotes
                  </span>
                </label>
              </div>
            </div>

            <div className={`mt-6 ${
              theme === 'light' ? 'bg-gray-50' : 'bg-gray-800'
            } rounded-lg p-4`}>
              <h3 className={`font-medium ${
                theme === 'light' ? 'text-gray-900' : 'text-white'
              } mb-2`}>Timer Methods</h3>
              <ul className={`space-y-2 text-sm ${
                theme === 'light' ? 'text-gray-600' : 'text-gray-400'
              }`}>
                <li className="flex items-start gap-2">
                  <Timer className="h-4 w-4 mt-1" />
                  <span>
                    <strong>Pomodoro:</strong> 25 minutes of work followed by 5-minute breaks
                  </span>
                </li>
                <li className="flex items-start gap-2">
                  <Coffee className="h-4 w-4 mt-1" />
                  <span>
                    <strong>52/17 Rule:</strong> 52 minutes of focused work followed by 17-minute breaks
                  </span>
                </li>
                <li className="flex items-start gap-2">
                  <Settings className="h-4 w-4 mt-1" />
                  <span>
                    <strong>Custom Timer:</strong> Set your own work and break durations
                  </span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      )}

      {showSettings && (
        <div className={`fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50`}>
          <div className={`${
            theme === 'light' ? 'bg-white' : 'bg-gray-900'
          } rounded-lg p-6 max-w-md w-full mx-4`}>
            <h3 className={`text-xl font-semibold ${
              theme === 'light' ? 'text-gray-900' : 'text-white'
            } mb-4`}>Custom Timer Settings</h3>
            <div className="space-y-4">
              <div>
                <label className={`block text-sm font-medium ${
                  theme === 'light' ? 'text-gray-700' : 'text-gray-300'
                }`}>
                  Work Duration (minutes)
                </label>
                <input
                  type="number"
                  value={customSettings.workDuration / 60}
                  onChange={(e) => setCustomSettings(prev => ({
                    ...prev,
                    workDuration: parseInt(e.target.value) * 60
                  }))}
                  className={`mt-1 block w-full rounded-md ${
                    theme === 'light'
                      ? 'border-gray-300'
                      : 'border-gray-600 bg-gray-800 text-white'
                  } shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50`}
                  min="1"
                />
              </div>
              <div>
                <label className={`block text-sm font-medium ${
                  theme === 'light' ? 'text-gray-700' : 'text-gray-300'
                }`}>
                  Break Duration (minutes)
                </label>
                <input
                  type="number"
                  value={customSettings.breakDuration / 60}
                  onChange={(e) => setCustomSettings(prev => ({
                    ...prev,
                    breakDuration: parseInt(e.target.value) * 60
                  }))}
                  className={`mt-1 block w-full rounded-md ${
                    theme === 'light'
                      ? 'border-gray-300'
                      : 'border-gray-600 bg-gray-800 text-white'
                  } shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50`}
                  min="1"
                />
              </div>
              <div>
                <label className={`block text-sm font-medium ${
                  theme === 'light' ? 'text-gray-700' : 'text-gray-300'
                }`}>
                  Long Break Duration (minutes)
                </label>
                <input
                  type="number"
                  value={customSettings.longBreakDuration / 60}
                  onChange={(e) => setCustomSettings(prev => ({
                    ...prev,
                    longBreakDuration: parseInt(e.target.value) * 60
                  }))}
                  className={`mt-1 block w-full rounded-md ${
                    theme === 'light'
                      ? 'border-gray-300'
                      : 'border-gray-600 bg-gray-800 text-white'
                  } shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50`}
                  min="1"
                />
              </div>
              <div>
                <label className={`block text-sm font-medium ${
                  theme === 'light' ? 'text-gray-700' : 'text-gray-300'
                }`}>
                  Sessions Before Long Break
                </label>
                <input
                  type="number"
                  value={customSettings.sessionsBeforeLongBreak}
                  onChange={(e) => setCustomSettings(prev => ({
                    ...prev,
                    sessionsBeforeLongBreak: parseInt(e.target.value)
                  }))}
                  className={`mt-1 block w-full rounded-md ${
                    theme === 'light'
                      ? 'border-gray-300'
                      : 'border-gray-600 bg-gray-800 text-white'
                  } shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50`}
                  min="1"
                />
              </div>
            </div>
            <div className="mt-6 flex justify-end space-x-3">
              <button
                onClick={() => setShowSettings(false)}
                className={`px-4 py-2 ${
                  theme === 'light'
                    ? 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                } rounded-lg`}
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  setShowSettings(false);
                  resetTimer();
                }}
                className={`px-4 py-2 ${
                  theme === 'light'
                    ? 'bg-indigo-600 text-white hover:bg-indigo-700'
                    : 'bg-indigo-500 text-white hover:bg-indigo-400'
                } rounded-lg`}
              >
                Save Settings
              </button>
            </div>
          </div>
        </div>
      )}

      <audio ref={audioRef}>
        <source src="https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3" type="audio/mpeg" />
      </audio>
    </>
  );
};

export default FocusMode;