import React, { useState } from 'react';
import { Task } from '../types';
import { ChevronLeft, ChevronRight, Calendar as CalendarIcon } from 'lucide-react';

interface CalendarProps {
  tasks: Task[];
}

const Calendar: React.FC<CalendarProps> = ({ tasks }) => {
  const [currentDate, setCurrentDate] = useState(new Date());

  const getDaysInMonth = (date: Date) => {
    return new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
  };

  const getFirstDayOfMonth = (date: Date) => {
    return new Date(date.getFullYear(), date.getMonth(), 1).getDay();
  };

  const getPreviousMonthDays = (date: Date) => {
    const firstDay = getFirstDayOfMonth(date);
    const prevMonthDays = [];
    if (firstDay > 0) {
      const daysInPrevMonth = getDaysInMonth(new Date(date.getFullYear(), date.getMonth() - 1));
      for (let i = firstDay - 1; i >= 0; i--) {
        prevMonthDays.push(daysInPrevMonth - i);
      }
    }
    return prevMonthDays;
  };

  const getNextMonthDays = (date: Date) => {
    const daysInMonth = getDaysInMonth(date);
    const lastDay = new Date(date.getFullYear(), date.getMonth(), daysInMonth).getDay();
    const nextMonthDays = [];
    if (lastDay < 6) {
      for (let i = 1; i <= 6 - lastDay; i++) {
        nextMonthDays.push(i);
      }
    }
    return nextMonthDays;
  };

  const getTasksForDate = (date: Date) => {
    return tasks.filter(task => {
      const taskDate = new Date(task.dueDate);
      return (
        taskDate.getDate() === date.getDate() &&
        taskDate.getMonth() === date.getMonth() &&
        taskDate.getFullYear() === date.getFullYear()
      );
    });
  };

  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  const weekDays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  const prevMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1));
  };

  const nextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1));
  };

  const goToToday = () => {
    setCurrentDate(new Date());
  };

  const renderCalendarDay = (dayNumber: number, isCurrentMonth: boolean = true) => {
    const date = new Date(currentDate.getFullYear(), currentDate.getMonth(), dayNumber);
    const tasksForDate = isCurrentMonth ? getTasksForDate(date) : [];
    const isToday = isCurrentMonth && 
      date.getDate() === new Date().getDate() &&
      date.getMonth() === new Date().getMonth() &&
      date.getFullYear() === new Date().getFullYear();

    return (
      <div
        className={`min-h-[100px] p-2 border border-gray-200 ${
          isCurrentMonth ? 'bg-white' : 'bg-gray-50'
        } ${isToday ? 'ring-2 ring-indigo-500 ring-inset' : ''}`}
      >
        <div className="flex items-center justify-between mb-1">
          <span className={`text-sm ${isCurrentMonth ? 'text-gray-900' : 'text-gray-400'}`}>
            {dayNumber}
          </span>
          {tasksForDate.length > 0 && (
            <span className="text-xs bg-indigo-100 text-indigo-600 px-2 py-0.5 rounded-full">
              {tasksForDate.length}
            </span>
          )}
        </div>
        <div className="space-y-1">
          {tasksForDate.map((task, index) => (
            <div
              key={task.id}
              className={`text-xs p-1 rounded truncate ${
                task.priority === 'high'
                  ? 'bg-red-100 text-red-800'
                  : task.priority === 'medium'
                  ? 'bg-yellow-100 text-yellow-800'
                  : 'bg-green-100 text-green-800'
              }`}
              title={task.title}
            >
              {task.title}
            </div>
          ))}
        </div>
      </div>
    );
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <CalendarIcon className="h-6 w-6 text-indigo-600" />
          <h2 className="text-2xl font-semibold text-gray-900">Calendar</h2>
        </div>
        <div className="flex items-center gap-4">
          <button
            onClick={goToToday}
            className="px-4 py-2 text-sm font-medium text-indigo-600 hover:bg-indigo-50 rounded-md"
          >
            Today
          </button>
          <div className="flex items-center gap-2">
            <button
              onClick={prevMonth}
              className="p-2 hover:bg-gray-100 rounded-full"
            >
              <ChevronLeft className="h-5 w-5 text-gray-600" />
            </button>
            <span className="text-lg font-medium text-gray-900">
              {monthNames[currentDate.getMonth()]} {currentDate.getFullYear()}
            </span>
            <button
              onClick={nextMonth}
              className="p-2 hover:bg-gray-100 rounded-full"
            >
              <ChevronRight className="h-5 w-5 text-gray-600" />
            </button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-7 gap-px bg-gray-200">
        {weekDays.map(day => (
          <div key={day} className="bg-gray-50 p-2 text-sm font-medium text-gray-900 text-center">
            {day}
          </div>
        ))}
        {getPreviousMonthDays(currentDate).map(day => renderCalendarDay(day, false))}
        {Array.from({ length: getDaysInMonth(currentDate) }, (_, i) => renderCalendarDay(i + 1))}
        {getNextMonthDays(currentDate).map(day => renderCalendarDay(day, false))}
      </div>

      <div className="mt-4 flex items-center gap-4">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 bg-red-100 rounded-full"></div>
          <span className="text-sm text-gray-600">High Priority</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 bg-yellow-100 rounded-full"></div>
          <span className="text-sm text-gray-600">Medium Priority</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 bg-green-100 rounded-full"></div>
          <span className="text-sm text-gray-600">Low Priority</span>
        </div>
      </div>
    </div>
  );
};

export default Calendar;