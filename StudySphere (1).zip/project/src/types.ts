import { User } from './types';

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'teacher' | 'student';
  subject?: string;
  class?: string;
}

export interface Task {
  id: string;
  title: string;
  description: string;
  type: string;
  priority: 'low' | 'medium' | 'high';
  dueDate: number;
  completed: boolean;
  subject?: string;
  assignedBy?: string;
  assignedTo?: string[];
  submission?: TaskSubmission;
  evaluation?: TaskEvaluation;
  teacherName?: string;
}

export interface TaskSubmission {
  id: string;
  taskId: string;
  studentId: string;
  fileUrl: string;
  notes: string;
  submittedAt: string;
}

export interface TaskEvaluation {
  id: string;
  submissionId: string;
  grade: 'A' | 'B' | 'C' | 'D' | 'F';
  score: number;
  comments: string;
  evaluatedAt: string;
  evaluatedBy: string;
}

export interface ChatMessage {
  id: string;
  text: string;
  sender: 'user' | 'bot';
  timestamp: number;
}

export interface ClassroomMember {
  id: string;
  name: string;
  role: 'teacher' | 'student';
  subject?: string;
  class?: string;
}

export interface StudentTask extends Task {
  grade?: string;
  score?: number;
  teacherName?: string;
}

export interface VideoLecture {
  id: string;
  title: string;
  description: string;
  videoUrl: string;
  thumbnailUrl?: string;
  subject: string;
  teacherId: string;
  teacherName: string;
  duration: number;
  uploadedAt: string;
  views: number;
}

export interface LiveSession {
  id: string;
  title: string;
  description: string;
  subject: string;
  teacherId: string;
  teacherName: string;
  scheduledFor: string;
  duration: number;
  meetingUrl: string;
  status: 'scheduled' | 'live' | 'ended';
  attendees: number;
}