import React, { useState } from 'react';
import { Users, GraduationCap, BookOpen, X, Star, Clock, Calendar, Table } from 'lucide-react';
import { ClassroomMember, StudentTask } from '../types';

interface ClassroomMembersProps {
  members: ClassroomMember[];
}

interface StudentDetailsModalProps {
  student: ClassroomMember;
  onClose: () => void;
  tasks: StudentTask[];
}

interface ScheduleModalProps {
  student: ClassroomMember;
  onClose: () => void;
}

interface TimetableModalProps {
  student: ClassroomMember;
  onClose: () => void;
}

const TimetableModal: React.FC<TimetableModalProps> = ({ student, onClose }) => {
  const timetable = {
    headers: ['Time', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'],
    rows: [
      ['9:00 - 10:00', 'English', 'Mathematics', 'Physics', 'English', 'Physics'],
      ['10:00 - 11:00', 'Physics', 'Computer Sci.', 'English', 'Mathematics', 'Computer Sci.'],
      ['11:00 - 11:15', 'Break', 'Break', 'Break', 'Break', 'Break'],
      ['11:15 - 12:15', 'Computer Sci.', 'Physics', 'Lab (Comp)', 'Lab (Phy)', 'Mathematics'],
      ['12:15 - 1:15', 'Mathematics', 'English', 'Lab (Comp)', 'Lab (Phy)', 'English'],
      ['1:15 - 2:00', 'Lunch', 'Lunch', 'Lunch', 'Lunch', 'Lunch'],
      ['2:00 - 3:00', 'Lab (Comp)', 'Lab (Phy)', 'Seminar/Club', 'Computer Sci.', 'Free Period'],
      ['3:00 - 4:00', 'Lab (Comp)', 'Lab (Phy)', 'Seminar/Club', 'Mathematics', 'Free Period']
    ]
  };

  const getCellStyle = (content: string) => {
    switch (content) {
      case 'Break':
        return 'bg-gray-100 text-gray-600';
      case 'Lunch':
        return 'bg-orange-50 text-orange-700';
      case 'Free Period':
        return 'bg-green-50 text-green-700';
      default:
        if (content.includes('Lab')) {
          return 'bg-purple-50 text-purple-700';
        } else if (content.includes('Seminar')) {
          return 'bg-yellow-50 text-yellow-700';
        }
        return 'bg-white';
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 max-w-5xl w-full mx-4">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h3 className="text-2xl font-semibold text-gray-900">
              {student.name}'s Class Timetable
            </h3>
            <p className="text-gray-600 mt-1">Weekly Schedule</p>
          </div>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700"
          >
            <X className="h-6 w-6" />
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr>
                {timetable.headers.map((header, index) => (
                  <th
                    key={index}
                    className={`
                      py-3 px-4 text-left bg-indigo-50 text-indigo-700 font-semibold
                      ${index === 0 ? 'sticky left-0 z-10 bg-indigo-50' : ''}
                      border border-indigo-100
                    `}
                  >
                    {header}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {timetable.rows.map((row, rowIndex) => (
                <tr key={rowIndex}>
                  {row.map((cell, cellIndex) => (
                    <td
                      key={cellIndex}
                      className={`
                        py-3 px-4 border border-gray-200
                        ${cellIndex === 0 ? 'sticky left-0 z-10 bg-gray-50 font-medium' : getCellStyle(cell)}
                      `}
                    >
                      {cell}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="mt-6 bg-gray-50 rounded-lg p-4">
          <div className="flex items-center gap-2 text-gray-700 mb-2">
            <Clock className="h-5 w-5" />
            <h4 className="font-medium">Legend</h4>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            <div className="flex items-center gap-2">
              <span className="w-4 h-4 bg-purple-50 border border-purple-200 rounded"></span>
              <span className="text-sm">Lab Sessions</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-4 h-4 bg-yellow-50 border border-yellow-200 rounded"></span>
              <span className="text-sm">Seminar/Club</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-4 h-4 bg-gray-100 border border-gray-200 rounded"></span>
              <span className="text-sm">Break</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-4 h-4 bg-orange-50 border border-orange-200 rounded"></span>
              <span className="text-sm">Lunch</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-4 h-4 bg-green-50 border border-green-200 rounded"></span>
              <span className="text-sm">Free Period</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const ScheduleModal: React.FC<ScheduleModalProps> = ({ student, onClose }) => {
  const schedule = [
    { time: '6:00 AM', activity: 'Wake up, freshen up', category: 'morning' },
    { time: '6:30 AM', activity: 'Morning exercise / walk / meditation', category: 'morning' },
    { time: '7:00 AM', activity: 'Breakfast', category: 'morning' },
    { time: '7:30 AM', activity: 'Quick review of subjects or homework', category: 'morning' },
    { time: '8:00 AM', activity: 'Leave for school / log in for online classes', category: 'morning' },
    { time: '8:30 AM - 3:30 PM', activity: 'School hours (includes lunch and short breaks)', category: 'school' },
    { time: '4:00 PM', activity: 'Snack / rest for a bit', category: 'afternoon' },
    { time: '4:30 PM', activity: 'Homework / assignments', category: 'afternoon' },
    { time: '5:30 PM', activity: 'Tuition / online class (if any)', category: 'afternoon' },
    { time: '6:30 PM', activity: 'Outdoor play / relaxation / hobby time', category: 'evening' },
    { time: '7:30 PM', activity: 'Dinner', category: 'evening' },
    { time: '8:00 PM', activity: 'Study / revision of what was learned today', category: 'evening' },
    { time: '9:00 PM', activity: 'Free time (phone, TV, reading, etc.)', category: 'evening' },
    { time: '9:30 PM', activity: 'Prepare for next day (bag, clothes, etc.)', category: 'evening' },
    { time: '10:00 PM', activity: 'Sleep', category: 'evening' }
  ];

  const getCategoryColor = (category: string) => {
    const colors = {
      morning: 'bg-yellow-50 border-l-4 border-yellow-400',
      school: 'bg-blue-50 border-l-4 border-blue-400',
      afternoon: 'bg-green-50 border-l-4 border-green-400',
      evening: 'bg-purple-50 border-l-4 border-purple-400'
    };
    return colors[category as keyof typeof colors] || 'bg-gray-50';
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 max-w-2xl w-full mx-4 max-h-[80vh] overflow-y-auto">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h3 className="text-2xl font-semibold text-gray-900">
              {student.name}'s Study Schedule
            </h3>
            <p className="text-gray-600 mt-1">Recommended daily routine for optimal learning</p>
          </div>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700"
          >
            <X className="h-6 w-6" />
          </button>
        </div>

        <div className="space-y-4">
          {schedule.map((item, index) => (
            <div
              key={index}
              className={`p-4 rounded-lg ${getCategoryColor(item.category)} transition-all hover:shadow-md`}
            >
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0">
                  <Clock className="h-5 w-5 text-gray-600" />
                </div>
                <div>
                  <p className="font-semibold text-gray-900">{item.time}</p>
                  <p className="text-gray-700">{item.activity}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-6 bg-indigo-50 rounded-lg p-4">
          <div className="flex items-center gap-2 text-indigo-700 mb-2">
            <Calendar className="h-5 w-5" />
            <h4 className="font-medium">Schedule Tips</h4>
          </div>
          <ul className="list-disc list-inside text-indigo-600 space-y-2">
            <li>Maintain consistent wake-up and bedtime</li>
            <li>Take short breaks between study sessions</li>
            <li>Include physical activity in your daily routine</li>
            <li>Review your day's learning before sleep</li>
            <li>Adjust schedule based on your energy levels</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

const StudentDetailsModal: React.FC<StudentDetailsModalProps> = ({ student, onClose, tasks }) => {
  const getGradeColor = (grade: string) => {
    const colors = {
      'A': 'text-green-600',
      'B': 'text-blue-600',
      'C': 'text-yellow-600',
      'D': 'text-orange-600',
      'F': 'text-red-600'
    };
    return colors[grade as keyof typeof colors] || 'text-gray-600';
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 max-w-2xl w-full mx-4 max-h-[80vh] overflow-y-auto">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-2xl font-semibold text-gray-900">{student.name}'s Progress</h3>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700"
          >
            <X className="h-6 w-6" />
          </button>
        </div>

        {tasks.length === 0 ? (
          <p className="text-gray-500 text-center py-8">No tasks assigned yet</p>
        ) : (
          <div className="space-y-4">
            {tasks.map((task) => (
              <div key={task.id} className="border rounded-lg p-4 bg-gray-50">
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="text-lg font-medium text-gray-900">{task.title}</h4>
                    <p className="text-sm text-gray-600">{task.description}</p>
                    {task.teacherName && (
                      <p className="text-sm text-indigo-600 mt-1">
                        Assigned by: {task.teacherName}
                      </p>
                    )}
                  </div>
                  {task.evaluation && (
                    <div className="flex items-center gap-2">
                      <Star className={`h-5 w-5 ${getGradeColor(task.evaluation.grade)}`} />
                      <span className={`font-bold ${getGradeColor(task.evaluation.grade)}`}>
                        {task.evaluation.grade} ({task.evaluation.score}%)
                      </span>
                    </div>
                  )}
                </div>
                
                <div className="mt-2 flex flex-wrap gap-2">
                  <span className={`px-2 py-1 rounded-full text-sm ${
                    task.priority === 'high'
                      ? 'bg-red-100 text-red-800'
                      : task.priority === 'medium'
                      ? 'bg-yellow-100 text-yellow-800'
                      : 'bg-green-100 text-green-800'
                  }`}>
                    {task.priority}
                  </span>
                  <span className="bg-indigo-50 text-indigo-700 px-2 py-1 rounded-full text-sm">
                    {task.type}
                  </span>
                  {task.subject && (
                    <span className="bg-purple-50 text-purple-700 px-2 py-1 rounded-full text-sm">
                      {task.subject}
                    </span>
                  )}
                  <span className="bg-gray-100 text-gray-700 px-2 py-1 rounded-full text-sm">
                    Due: {new Date(task.dueDate).toLocaleDateString()}
                  </span>
                </div>

                {task.evaluation?.comments && (
                  <p className="mt-2 text-sm text-gray-600 bg-white p-2 rounded">
                    <span className="font-medium">Feedback:</span> {task.evaluation.comments}
                  </p>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

const ClassroomMembers: React.FC<ClassroomMembersProps> = ({ members: propMembers }) => {
  const [selectedStudent, setSelectedStudent] = useState<ClassroomMember | null>(null);
  const [showSchedule, setShowSchedule] = useState<ClassroomMember | null>(null);
  const [showTimetable, setShowTimetable] = useState<ClassroomMember | null>(null);
  
  // Mock tasks data - In a real app, this would come from your database
  const mockTasks: StudentTask[] = [
    {
      id: '1',
      title: 'Mathematics Assignment 1',
      description: 'Solve quadratic equations',
      type: 'homework',
      priority: 'high',
      dueDate: Date.now() + 86400000,
      completed: true,
      subject: 'Mathematics',
      teacherName: 'Mrs. Smith',
      evaluation: {
        id: '1',
        submissionId: '1',
        grade: 'A',
        score: 95,
        comments: 'Excellent work! Very thorough solutions.',
        evaluatedAt: new Date().toISOString(),
        evaluatedBy: '1'
      }
    },
    {
      id: '2',
      title: 'Science Project',
      description: 'Research on renewable energy',
      type: 'project',
      priority: 'medium',
      dueDate: Date.now() + 172800000,
      completed: false,
      subject: 'Science',
      teacherName: 'Mr. Johnson'
    }
  ];

  // Default members
  const defaultMembers: ClassroomMember[] = [
    {
      id: 'teacher-1',
      name: 'Mrs. Smith',
      role: 'teacher',
      subject: 'Computer Science'
    },
    ...Array.from({ length: 30 }, (_, i) => ({
      id: `student-${i + 1}`,
      name: `Student ${i + 1}`,
      role: 'student' as const
    }))
  ];

  const allMembers = [...propMembers, ...defaultMembers.filter(defaultMember => 
    !propMembers.some(propMember => propMember.id === defaultMember.id)
  )];

  const teachers = allMembers.filter(member => member.role === 'teacher');
  const students = allMembers.filter(member => member.role === 'student');

  return (
    <div className="bg-white/80 backdrop-blur-sm rounded-lg shadow-md p-6">
      <h2 className="text-2xl font-semibold text-gray-900 mb-6 flex items-center gap-2">
        <Users className="h-6 w-6 text-indigo-600" />
        Classroom Members
      </h2>

      {/* Teachers Section */}
      <div className="mb-8">
        <h3 className="text-lg font-medium text-gray-900 mb-4 flex items-center gap-2">
          <GraduationCap className="h-5 w-5 text-indigo-600" />
          Teachers
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {teachers.map(teacher => (
            <div
              key={teacher.id}
              className="bg-indigo-50 rounded-lg p-4 flex items-start space-x-4"
            >
              <div className="flex-shrink-0">
                <div className="w-10 h-10 rounded-full bg-indigo-200 flex items-center justify-center">
                  <GraduationCap className="h-6 w-6 text-indigo-600" />
                </div>
              </div>
              <div>
                <h4 className="text-lg font-medium text-gray-900">{teacher.name}</h4>
                {teacher.subject && (
                  <p className="text-sm text-gray-600">
                    Subject: {teacher.subject}
                  </p>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Students Section */}
      <div>
        <h3 className="text-lg font-medium text-gray-900 mb-4 flex items-center gap-2">
          <BookOpen className="h-5 w-5 text-indigo-600" />
          Students ({students.length})
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {students.map(student => (
            <div
              key={student.id}
              className="bg-pink-50 rounded-lg p-4 flex items-start space-x-4"
            >
              <div className="flex-shrink-0">
                <div className="w-10 h-10 rounded-full bg-pink-200 flex items-center justify-center">
                  <BookOpen className="h-6 w-6 text-pink-600" />
                </div>
              </div>
              <div className="flex-1">
                <h4 className="text-lg font-medium text-gray-900">{student.name}</h4>
                <div className="mt-2 space-x-2">
                  <button
                    onClick={() => setSelectedStudent(student)}
                    className="text-sm text-indigo-600 hover:text-indigo-800"
                  >
                    View Progress
                  </button>
                  <span className="text-gray-300">|</span>
                  <button
                    onClick={() => setShowSchedule(student)}
                    className="text-sm text-pink-600 hover:text-pink-800"
                  >
                    Study Schedule
                  </button>
                  <span className="text-gray-300">|</span>
                  <button
                    onClick={() => setShowTimetable(student)}
                    className="text-sm text-green-600 hover:text-green-800"
                  >
                    View Timetable
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {selectedStudent && (
        <StudentDetailsModal
          student={selectedStudent}
          onClose={() => setSelectedStudent(null)}
          tasks={mockTasks}
        />
      )}

      {showSchedule && (
        <ScheduleModal
          student={showSchedule}
          onClose={() => setShowSchedule(null)}
        />
      )}

      {showTimetable && (
        <TimetableModal
          student={showTimetable}
          onClose={() => setShowTimetable(null)}
        />
      )}
    </div>
  );
};

export default ClassroomMembers;