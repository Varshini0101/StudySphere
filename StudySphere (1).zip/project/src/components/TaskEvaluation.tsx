import React, { useState } from 'react';
import { CheckCircle, Star } from 'lucide-react';
import { Task, User } from '../types';

interface TaskEvaluationProps {
  task: Task;
  currentUser: User;
  onEvaluate: (taskId: string, evaluation: { grade: 'A' | 'B' | 'C' | 'D' | 'F'; score: number; comments: string }) => void;
}

const TaskEvaluation: React.FC<TaskEvaluationProps> = ({ task, currentUser, onEvaluate }) => {
  const [grade, setGrade] = useState<'A' | 'B' | 'C' | 'D' | 'F'>('A');
  const [score, setScore] = useState<number>(100);
  const [comments, setComments] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onEvaluate(task.id, { grade, score, comments });
    setGrade('A');
    setScore(100);
    setComments('');
  };

  const getGradeColor = (grade: string) => {
    const colors = {
      'A': 'text-green-600',
      'B': 'text-blue-600',
      'C': 'text-yellow-600',
      'D': 'text-orange-600',
      'F': 'text-red-600'
    };
    return colors[grade as keyof typeof colors] || 'text-gray-600';
  };

  if (!task.submission) {
    return (
      <div className="text-gray-500 italic mt-2">
        Waiting for submission...
      </div>
    );
  }

  if (task.evaluation) {
    return (
      <div className="bg-green-50 rounded-lg p-4 mt-2">
        <div className="flex items-center gap-2 text-green-600 mb-2">
          <CheckCircle className="h-5 w-5" />
          <span>Evaluated</span>
        </div>
        <div className="flex items-center gap-2 mb-2">
          <Star className={`h-5 w-5 ${getGradeColor(task.evaluation.grade)}`} />
          <span className={`font-bold ${getGradeColor(task.evaluation.grade)}`}>
            Grade: {task.evaluation.grade} ({task.evaluation.score}%)
          </span>
        </div>
        <p className="text-gray-700">Comments: {task.evaluation.comments}</p>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="mt-4 space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label htmlFor="grade" className="block text-sm font-medium text-gray-700">
            Grade
          </label>
          <select
            id="grade"
            value={grade}
            onChange={(e) => setGrade(e.target.value as 'A' | 'B' | 'C' | 'D' | 'F')}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
            required
          >
            <option value="A">A (90-100)</option>
            <option value="B">B (80-89)</option>
            <option value="C">C (70-79)</option>
            <option value="D">D (60-69)</option>
            <option value="F">F (Below 60)</option>
          </select>
        </div>

        <div>
          <label htmlFor="score" className="block text-sm font-medium text-gray-700">
            Score (%)
          </label>
          <input
            type="number"
            id="score"
            min="0"
            max="100"
            value={score}
            onChange={(e) => setScore(Number(e.target.value))}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
            required
          />
        </div>
      </div>

      <div>
        <label htmlFor="comments" className="block text-sm font-medium text-gray-700">
          Feedback Comments
        </label>
        <textarea
          id="comments"
          value={comments}
          onChange={(e) => setComments(e.target.value)}
          rows={3}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
          placeholder="Provide detailed feedback on the submission..."
          required
        />
      </div>

      <button
        type="submit"
        className="w-full bg-indigo-600 text-white py-2 px-4 rounded-md hover:bg-indigo-700 transition-colors flex items-center justify-center gap-2"
      >
        <Star className="h-5 w-5" />
        Submit Evaluation
      </button>
    </form>
  );
};

export default TaskEvaluation;