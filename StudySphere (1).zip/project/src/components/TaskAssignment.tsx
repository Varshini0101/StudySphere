import React, { useState } from 'react';
import { Task, User } from '../types';
import { ClipboardList } from 'lucide-react';

interface TaskAssignmentProps {
  currentUser: User;
  users: User[];
  onAssignTask: (task: Omit<Task, 'id'>) => void;
}

const TaskAssignment: React.FC<TaskAssignmentProps> = ({ currentUser, users, onAssignTask }) => {
  const [task, setTask] = useState({
    title: '',
    description: '',
    type: 'homework',
    priority: 'medium' as const,
    dueDate: Date.now(),
    completed: false,
    subject: currentUser.subject || '',
    assignedTo: [] as string[]
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Get all student IDs
    const studentIds = users.filter(user => user.role === 'student').map(user => user.id);
    
    onAssignTask({
      ...task,
      assignedTo: studentIds, // Assign to all students automatically
      dueDate: new Date(task.dueDate).getTime()
    });

    // Reset form
    setTask({
      title: '',
      description: '',
      type: 'homework',
      priority: 'medium',
      dueDate: Date.now(),
      completed: false,
      subject: currentUser.subject || '',
      assignedTo: []
    });
  };

  return (
    <div>
      <div className="flex items-center gap-2 mb-6">
        <ClipboardList className="h-6 w-6 text-indigo-600" />
        <h2 className="text-2xl font-semibold text-gray-900">Create New Task</h2>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label htmlFor="title" className="block text-sm font-medium text-gray-700">
              Title
            </label>
            <input
              type="text"
              id="title"
              value={task.title}
              onChange={(e) => setTask({ ...task, title: e.target.value })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
              required
            />
          </div>

          <div>
            <label htmlFor="subject" className="block text-sm font-medium text-gray-700">
              Subject
            </label>
            <input
              type="text"
              id="subject"
              value={task.subject}
              onChange={(e) => setTask({ ...task, subject: e.target.value })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
              required
            />
          </div>
        </div>

        <div>
          <label htmlFor="description" className="block text-sm font-medium text-gray-700">
            Description
          </label>
          <textarea
            id="description"
            value={task.description}
            onChange={(e) => setTask({ ...task, description: e.target.value })}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
            rows={3}
            required
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div>
            <label htmlFor="type" className="block text-sm font-medium text-gray-700">
              Type
            </label>
            <select
              id="type"
              value={task.type}
              onChange={(e) => setTask({ ...task, type: e.target.value })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
            >
              <option value="homework">Homework</option>
              <option value="quiz">Quiz</option>
              <option value="project">Project</option>
              <option value="test">Test</option>
            </select>
          </div>

          <div>
            <label htmlFor="priority" className="block text-sm font-medium text-gray-700">
              Priority
            </label>
            <select
              id="priority"
              value={task.priority}
              onChange={(e) => setTask({ ...task, priority: e.target.value as 'low' | 'medium' | 'high' })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
            >
              <option value="low">Low</option>
              <option value="medium">Medium</option>
              <option value="high">High</option>
            </select>
          </div>

          <div>
            <label htmlFor="dueDate" className="block text-sm font-medium text-gray-700">
              Due Date
            </label>
            <input
              type="datetime-local"
              id="dueDate"
              value={new Date(task.dueDate).toISOString().slice(0, 16)}
              onChange={(e) => setTask({ ...task, dueDate: new Date(e.target.value).getTime() })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
              required
            />
          </div>
        </div>

        <div className="bg-blue-50 rounded-lg p-4 mt-4">
          <p className="text-sm text-blue-600">
            This task will be automatically assigned to all registered students.
          </p>
          <p className="text-sm text-blue-600 mt-1">
            Current number of students: 30
          </p>
        </div>

        <button
          type="submit"
          className="w-full bg-indigo-600 text-white py-3 px-4 rounded-md hover:bg-indigo-700 transition-colors flex items-center justify-center gap-2"
        >
          <ClipboardList className="h-5 w-5" />
          Create and Assign Task
        </button>
      </form>
    </div>
  );
};

export default TaskAssignment;