import React, { useState } from 'react';
import { Mic, MicOff, Brain, Sparkles, Users, BookOpen, Video, Globe } from 'lucide-react';
import TaskList from './components/TaskList';
import VoiceControl from './components/VoiceControl';
import InsightsDashboard from './components/InsightsDashboard';
import ChatInterface from './components/ChatInterface';
import UserRegistration from './components/UserRegistration';
import TaskAssignment from './components/TaskAssignment';
import ClassroomMembers from './components/ClassroomMembers';
import TeacherDashboard from './components/TeacherDashboard';
import FocusMode from './components/FocusMode';
import Calendar from './components/Calendar';
import { Task, User, TaskSubmission, TaskEvaluation, ClassroomMember } from './types';

function App() {
  const [isListening, setIsListening] = useState(false);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [selectedLanguage, setSelectedLanguage] = useState('en-US');
  const [users, setUsers] = useState<User[]>([]);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [showRegistration, setShowRegistration] = useState(false);

  const toggleListening = () => {
    setIsListening(!isListening);
  };

  const handleTaskUpdate = (taskId: string, updates: Partial<Task>) => {
    setTasks(prevTasks =>
      prevTasks.map(task =>
        task.id === taskId ? { ...task, ...updates } : task
      )
    );
  };

  const handleUserRegister = (userData: Omit<User, 'id'>) => {
    const newUser: User = {
      ...userData,
      id: `user-${Date.now()}`
    };
    setUsers(prev => [...prev, newUser]);
    setCurrentUser(newUser);
  };

  const handleAssignTask = (taskData: Omit<Task, 'id'>) => {
    const studentIds = users.filter(user => user.role === 'student').map(user => user.id);
    
    const newTask: Task = {
      ...taskData,
      id: `task-${Date.now()}`,
      assignedBy: currentUser?.id,
      assignedTo: studentIds,
      teacherName: currentUser?.name
    };
    setTasks(prev => [...prev, newTask]);
  };

  const handleSubmission = (taskId: string, submission: { fileUrl: string; notes: string }) => {
    const newSubmission: TaskSubmission = {
      id: `submission-${Date.now()}`,
      taskId,
      studentId: currentUser!.id,
      fileUrl: submission.fileUrl,
      notes: submission.notes,
      submittedAt: new Date().toISOString()
    };

    setTasks(prev =>
      prev.map(task =>
        task.id === taskId
          ? { ...task, submission: newSubmission }
          : task
      )
    );
  };

  const handleEvaluation = (taskId: string, evaluation: { grade: string; comments: string }) => {
    const task = tasks.find(t => t.id === taskId);
    if (!task?.submission) return;

    const newEvaluation: TaskEvaluation = {
      id: `evaluation-${Date.now()}`,
      submissionId: task.submission.id,
      grade: evaluation.grade as 'A' | 'B' | 'C' | 'D' | 'F',
      score: 95, // Example score
      comments: evaluation.comments,
      evaluatedAt: new Date().toISOString(),
      evaluatedBy: currentUser!.id
    };

    setTasks(prev =>
      prev.map(task =>
        task.id === taskId
          ? { ...task, evaluation: newEvaluation }
          : task
      )
    );
  };

  const userTasks = currentUser?.role === 'teacher'
    ? tasks.filter(task => task.assignedBy === currentUser.id)
    : tasks.filter(task => task.assignedTo?.includes(currentUser?.id || ''));

  const classroomMembers: ClassroomMember[] = users.map(user => ({
    id: user.id,
    name: user.name,
    role: user.role,
    subject: user.subject,
    class: user.class
  }));

  if (!currentUser && !showRegistration) {
    return (
      <div className="min-h-screen bg-gradient-radial from-dark-magenta-950 via-dark-magenta-900 to-dark-magenta-950 flex items-center justify-center">
        <div className="text-center space-y-8 p-8 bg-black/20 backdrop-blur-lg rounded-2xl shadow-xl max-w-2xl mx-4 border border-dark-magenta-500/20">
          <div className="flex items-center justify-center space-x-4 animate-float">
            <Brain className="h-16 w-16 text-custom-magenta-400 animate-glow" />
            <h1 className="text-5xl font-bold bg-gradient-to-r from-custom-magenta-400 to-custom-magenta-600 text-transparent bg-clip-text neon-text">
              StudySphere
            </h1>
          </div>
          
          <p className="text-xl text-custom-magenta-100 max-w-lg mx-auto">
            Your comprehensive learning management system designed for seamless collaboration between teachers and students.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-left">
            <div className="p-6 bg-dark-magenta-900/50 rounded-xl shadow-md border border-dark-magenta-700/50 hover:border-dark-magenta-500/50 transition-all duration-300 group">
              <Sparkles className="h-8 w-8 text-custom-magenta-400 mb-4 group-hover:animate-glow" />
              <h3 className="text-lg font-semibold mb-2 text-custom-magenta-200">Smart Learning</h3>
              <p className="text-custom-magenta-300">Intelligent task management and progress tracking for enhanced learning outcomes.</p>
            </div>
            
            <div className="p-6 bg-dark-magenta-900/50 rounded-xl shadow-md border border-dark-magenta-700/50 hover:border-dark-magenta-500/50 transition-all duration-300 group">
              <Video className="h-8 w-8 text-custom-magenta-400 mb-4 group-hover:animate-glow" />
              <h3 className="text-lg font-semibold mb-2 text-custom-magenta-200">Video Lectures</h3>
              <p className="text-custom-magenta-300">Access high-quality video lectures and live sessions for interactive learning.</p>
            </div>
            
            <div className="p-6 bg-dark-magenta-900/50 rounded-xl shadow-md border border-dark-magenta-700/50 hover:border-dark-magenta-500/50 transition-all duration-300 group">
              <Globe className="h-8 w-8 text-custom-magenta-400 mb-4 group-hover:animate-glow" />
              <h3 className="text-lg font-semibold mb-2 text-custom-magenta-200">Live Sessions</h3>
              <p className="text-custom-magenta-300">Join interactive live sessions for real-time learning and discussions.</p>
            </div>
          </div>

          <button
            onClick={() => setShowRegistration(true)}
            className="px-8 py-4 bg-gradient-to-r from-custom-magenta-600 to-custom-magenta-700 text-white rounded-full text-lg font-semibold hover:from-custom-magenta-500 hover:to-custom-magenta-600 transition-all duration-300 shadow-lg hover:shadow-custom-magenta-500/50 transform hover:-translate-y-1 neon-border"
          >
            Get Started →
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-dark-magenta-950 via-dark-magenta-900 to-dark-magenta-950">
      <nav className="bg-black/20 backdrop-blur-lg shadow-lg border-b border-dark-magenta-500/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <Brain className="h-8 w-8 text-custom-magenta-400 animate-glow" />
              <span className="ml-2 text-xl font-semibold text-custom-magenta-200 neon-text">StudySphere</span>
            </div>
            <div className="flex items-center space-x-4">
              {currentUser && (
                <span className="text-sm text-custom-magenta-200">
                  Welcome, {currentUser.name} ({currentUser.role})
                </span>
              )}
              <select
                value={selectedLanguage}
                onChange={(e) => setSelectedLanguage(e.target.value)}
                className="rounded-md border-dark-magenta-700 bg-dark-magenta-900/50 text-custom-magenta-200 shadow-sm focus:border-custom-magenta-500 focus:ring focus:ring-custom-magenta-500/50"
              >
                <option value="en-US">English</option>
                <option value="ta-IN">Tamil</option>
                <option value="ml-IN">Malayalam</option>
                <option value="te-IN">Telugu</option>
                <option value="kn-IN">Kannada</option>
                <option value="hi-IN">Hindi</option>
                <option value="bn-IN">Bengali</option>
                <option value="mr-IN">Marathi</option>
                <option value="gu-IN">Gujarati</option>
                <option value="pa-IN">Punjabi</option>
              </select>
              <button
                onClick={toggleListening}
                className={`p-2 rounded-full transition-all duration-300 ${
                  isListening 
                    ? 'bg-custom-magenta-900/50 text-custom-magenta-400 animate-pulse' 
                    : 'bg-dark-magenta-900/50 text-custom-magenta-400 hover:bg-dark-magenta-800/50'
                }`}
              >
                {isListening ? <MicOff className="h-6 w-6" /> : <Mic className="h-6 w-6" />}
              </button>
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {!currentUser ? (
          <div className="max-w-md mx-auto">
            <UserRegistration onUserRegister={handleUserRegister} />
          </div>
        ) : (
          <div className="space-y-8">
            {/* Voice Control Section */}
            <div className="bg-white/80 backdrop-blur-sm rounded-lg shadow-md p-6">
              <VoiceControl
                isListening={isListening}
                language={selectedLanguage}
                onTaskDetected={(task) => handleAssignTask({ ...task, assignedTo: [] })}
              />
            </div>

            {/* Calendar View */}
            <Calendar tasks={userTasks} />

            <ClassroomMembers members={classroomMembers} />

            {currentUser.role === 'teacher' && (
              <TeacherDashboard currentUser={currentUser} />
            )}

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              <div className="lg:col-span-8 space-y-8">
                {currentUser.role === 'teacher' && (
                  <div className="bg-white/80 backdrop-blur-sm rounded-lg shadow-md p-6">
                    <TaskAssignment
                      currentUser={currentUser}
                      users={users}
                      onAssignTask={handleAssignTask}
                    />
                  </div>
                )}

                <div className="bg-white/80 backdrop-blur-sm rounded-lg shadow-md p-6">
                  <TaskList
                    tasks={userTasks}
                    currentUser={currentUser}
                    onSubmit={handleSubmission}
                    onEvaluate={handleEvaluation}
                  />
                </div>
              </div>

              <div className="lg:col-span-4 space-y-8">
                <ChatInterface tasks={userTasks} onTaskUpdate={handleTaskUpdate} />
                <InsightsDashboard tasks={userTasks} />
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Focus Mode is always available through the floating button */}
      <FocusMode />
    </div>
  );
}

export default App;