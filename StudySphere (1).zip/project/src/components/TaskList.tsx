import React, { useState } from 'react';
import { Calendar, CheckCircle, Clock, AlertTriangle, User as UserIcon, Timer, Play, Pause, RotateCcw } from 'lucide-react';
import { Task, User } from '../types';
import TaskSubmission from './TaskSubmission';
import TaskEvaluation from './TaskEvaluation';

interface TaskListProps {
  tasks: Task[];
  currentUser: User;
  onSubmit: (taskId: string, submission: { fileUrl: string; notes: string }) => void;
  onEvaluate: (taskId: string, evaluation: { grade: string; comments: string }) => void;
}

interface TaskTimer {
  taskId: string;
  timeLeft: number;
  isRunning: boolean;
  intervalId?: NodeJS.Timeout;
}

const TaskList: React.FC<TaskListProps> = ({ tasks, currentUser, onSubmit, onEvaluate }) => {
  const isTeacher = currentUser.role === 'teacher';
  const [timers, setTimers] = useState<TaskTimer[]>([]);

  const startTimer = (taskId: string, duration: number) => {
    // Clear existing timer if any
    const existingTimer = timers.find(t => t.taskId === taskId);
    if (existingTimer?.intervalId) {
      clearInterval(existingTimer.intervalId);
    }

    const intervalId = setInterval(() => {
      setTimers(prev => prev.map(timer => {
        if (timer.taskId === taskId && timer.isRunning) {
          const newTimeLeft = timer.timeLeft - 1;
          if (newTimeLeft <= 0) {
            clearInterval(timer.intervalId);
            // Play notification sound
            const audio = new Audio('https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3');
            audio.play();
            return { ...timer, timeLeft: 0, isRunning: false };
          }
          return { ...timer, timeLeft: newTimeLeft };
        }
        return timer;
      }));
    }, 1000);

    setTimers(prev => {
      const existing = prev.find(t => t.taskId === taskId);
      if (existing) {
        return prev.map(t => 
          t.taskId === taskId 
            ? { ...t, timeLeft: duration * 60, isRunning: true, intervalId } 
            : t
        );
      }
      return [...prev, { taskId, timeLeft: duration * 60, isRunning: true, intervalId }];
    });
  };

  const pauseTimer = (taskId: string) => {
    setTimers(prev => prev.map(timer => {
      if (timer.taskId === taskId) {
        if (timer.intervalId) {
          clearInterval(timer.intervalId);
        }
        return { ...timer, isRunning: false };
      }
      return timer;
    }));
  };

  const resetTimer = (taskId: string) => {
    const timer = timers.find(t => t.taskId === taskId);
    if (timer?.intervalId) {
      clearInterval(timer.intervalId);
    }
    setTimers(prev => prev.filter(t => t.taskId !== taskId));
  };

  const formatTime = (seconds: number) => {
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    
    if (hrs > 0) {
      return `${hrs}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const sortedTasks = [...tasks].sort((a, b) => {
    // Sort by completion status first
    if (a.completed !== b.completed) {
      return a.completed ? 1 : -1;
    }
    // Then sort by due date
    return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
  });

  return (
    <div>
      <h2 className="text-2xl font-semibold text-gray-900 mb-4">
        {isTeacher ? 'Assigned Tasks' : 'My Tasks'}
      </h2>
      {sortedTasks.length === 0 ? (
        <div className="text-center py-8 text-gray-500">
          <AlertTriangle className="h-12 w-12 mx-auto mb-4 text-gray-400" />
          <p className="text-lg">No tasks found</p>
          <p className="text-sm">
            {isTeacher
              ? "You haven't assigned any tasks yet"
              : "You don't have any assigned tasks"}
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {sortedTasks.map((task) => {
            const timer = timers.find(t => t.taskId === task.id);
            
            return (
              <div
                key={task.id}
                className={`border rounded-lg p-4 transition-all ${
                  task.completed
                    ? 'bg-gray-50 border-gray-200'
                    : 'bg-white border-gray-200 hover:shadow-md'
                }`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <h3 className="text-lg font-medium text-gray-900">{task.title}</h3>
                      {task.completed && (
                        <span className="flex items-center text-green-600 text-sm">
                          <CheckCircle className="h-4 w-4 mr-1" />
                          Completed
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-gray-500 mt-1">{task.description}</p>
                    
                    {/* Show teacher name for students */}
                    {!isTeacher && task.teacherName && (
                      <p className="text-sm text-indigo-600 mt-1 flex items-center">
                        <UserIcon className="h-4 w-4 mr-1" />
                        Assigned by: {task.teacherName}
                      </p>
                    )}
                  </div>
                  <span
                    className={`px-2 py-1 rounded-full text-sm ${
                      task.priority === 'high'
                        ? 'bg-red-100 text-red-800'
                        : task.priority === 'medium'
                        ? 'bg-yellow-100 text-yellow-800'
                        : 'bg-green-100 text-green-800'
                    }`}
                  >
                    {task.priority}
                  </span>
                </div>
                
                <div className="mt-4 flex items-center space-x-4 text-sm text-gray-500">
                  <div className="flex items-center">
                    <Calendar className="h-4 w-4 mr-1" />
                    <span>
                      {new Date(task.dueDate).toLocaleDateString('en-US', {
                        month: 'short',
                        day: 'numeric',
                        year: 'numeric'
                      })}
                    </span>
                  </div>
                  <div className="flex items-center">
                    <Clock className="h-4 w-4 mr-1" />
                    <span className="capitalize">{task.type}</span>
                  </div>
                  {task.subject && (
                    <span className="bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded">
                      {task.subject}
                    </span>
                  )}
                </div>

                {/* Timer Controls for Students */}
                {!isTeacher && !task.completed && (
                  <div className="mt-4 flex items-center gap-4 p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center gap-2">
                      <Timer className="h-5 w-5 text-indigo-600" />
                      <input
                        type="number"
                        min="1"
                        placeholder="Minutes"
                        className="w-20 px-2 py-1 border rounded"
                        onChange={(e) => {
                          const duration = parseInt(e.target.value);
                          if (duration > 0) {
                            startTimer(task.id, duration);
                          }
                        }}
                        disabled={timer?.isRunning}
                      />
                    </div>
                    
                    {timer && (
                      <>
                        <div className="text-lg font-mono font-medium text-indigo-600">
                          {formatTime(timer.timeLeft)}
                        </div>
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => timer.isRunning ? pauseTimer(task.id) : startTimer(task.id, Math.ceil(timer.timeLeft / 60))}
                            className={`p-2 rounded-full ${
                              timer.isRunning
                                ? 'bg-red-100 text-red-600 hover:bg-red-200'
                                : 'bg-green-100 text-green-600 hover:bg-green-200'
                            }`}
                          >
                            {timer.isRunning ? (
                              <Pause className="h-4 w-4" />
                            ) : (
                              <Play className="h-4 w-4" />
                            )}
                          </button>
                          <button
                            onClick={() => resetTimer(task.id)}
                            className="p-2 rounded-full bg-gray-100 text-gray-600 hover:bg-gray-200"
                          >
                            <RotateCcw className="h-4 w-4" />
                          </button>
                        </div>
                      </>
                    )}
                  </div>
                )}

                {!isTeacher && (
                  <TaskSubmission
                    task={task}
                    currentUser={currentUser}
                    onSubmit={onSubmit}
                  />
                )}

                {isTeacher && task.submission && (
                  <TaskEvaluation
                    task={task}
                    currentUser={currentUser}
                    onEvaluate={onEvaluate}
                  />
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default TaskList;